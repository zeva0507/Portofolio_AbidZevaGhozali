<?php 
@ob_start();
session_start();
if(empty($_SESSION['admin'])) {
    echo '<script>window.location="login.php";</script>';
    exit;
}
require 'config.php';
include $view;
$lihat = new view($config);
$toko = $lihat->toko();

$sql = "
    SELECT 
        penjualan.id_barang, 
        barang.nama_barang, 
        barang.merk, 
        penjualan.jumlah, 
        (barang.harga_jual * penjualan.jumlah) AS total 
    FROM 
        penjualan 
    JOIN 
        barang ON penjualan.id_barang = barang.id_barang
";
$row = $config->prepare($sql);
$row->execute();
$hsl = $row->fetchAll();
?>

<html>
<head>
    <title>Laporan Transaksi</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px; /* Tambahkan margin untuk tampilan cetak */
        }
        .header, .footer {
            text-align: center;
            margin-bottom: 20px;
        }
        .table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        .table th, .table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2;
        }
        .total {
            text-align: right;
            margin-top: 20px;
        }
        @media print {
            body {
                -webkit-print-color-adjust: exact; 
                margin: 0; /* Menghilangkan margin default */
                padding: 20px; /* Tambahkan padding jika perlu */
            }
            .header, .footer {
                page-break-after: avoid; 
                margin-bottom: 20px; 
            }
            .table {
                page-break-inside: avoid; 
            }
            button {
                display: none; 
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h2><?php echo $toko['nama_toko']; ?></h2>
        <p><?php echo $toko['alamat_toko']; ?></p>
        <p>Tanggal: <?php echo date("j F Y, G:i"); ?></p>
        <p>Kasir: <?php echo htmlentities($_GET['nm_member']); ?></p>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>No.</th>
                <th>Barang</th>
                <th>Merk</th>
                <th>Jumlah</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($hsl as $isi) { ?>
                <tr>
                    <td><?php echo $no; ?></td>
                    <td><?php echo $isi['nama_barang']; ?></td>
                    <td><?php echo $isi['merk']; ?></td>
                    <td><?php echo $isi['jumlah']; ?></td>
                    <td>Rp. <?php echo number_format($isi['total']); ?></td>
                </tr>
            <?php $no++; } ?>
        </tbody>
    </table>

    <div class="total">
        <?php $hasil = $lihat->jumlah(); ?>
        <p>Total: Rp. <?php echo number_format($hasil['bayar']); ?>,-</p>
        <p>Bayar: Rp. <?php echo number_format(htmlentities($_GET['bayar'])); ?>,-</p>
        <p>Kembali: Rp. <?php echo number_format(htmlentities($_GET['kembali'])); ?>,-</p>
    </div>

    <div class="footer">
        <p>Terima Kasih Telah berbelanja di toko kami!</p>
        <p>GROW AND GLOW YOUR SKIN WITH US</p>
    </div>

    <script>
        window.print(); // Dialog cetak otomatis saat halaman dimuat
    </script>
</body>
</html>