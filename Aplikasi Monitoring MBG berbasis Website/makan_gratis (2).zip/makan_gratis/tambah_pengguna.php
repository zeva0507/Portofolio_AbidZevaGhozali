<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $alamat = $_POST['alamat'];

    // Check if username already exists
    $check = $conn->prepare("SELECT id FROM user WHERE username = ?");
    $check->bind_param("s", $username);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Username sudah digunakan!";
    } else {
        $stmt = $conn->prepare("INSERT INTO user (nama, username, password, role, alamat) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nama, $username, $password, $role, $alamat);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Pengguna berhasil ditambahkan!";
        } else {
            $_SESSION['error'] = "Gagal menambahkan pengguna!";
        }
        $stmt->close();
    }
}

header("Location: dashboard_admin.php?menu=pengguna");
exit;
