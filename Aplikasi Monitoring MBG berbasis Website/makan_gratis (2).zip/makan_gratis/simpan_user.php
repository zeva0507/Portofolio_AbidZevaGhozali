<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

if (isset($_POST['tambah_user'])) {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $stmt = $conn->prepare("INSERT INTO user (nama, username, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nama, $username, $password, $role);
    $stmt->execute();
    $stmt->close();
} elseif (isset($_POST['edit_user'])) {
    $id = intval($_POST['id']);
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $role = $_POST['role'];

    // Jika password diisi, update password juga
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE user SET nama=?, username=?, password=?, role=? WHERE id=?");
        $stmt->bind_param("ssssi", $nama, $username, $password, $role, $id);
    } else {
        $stmt = $conn->prepare("UPDATE user SET nama=?, username=?, role=? WHERE id=?");
        $stmt->bind_param("sssi", $nama, $username, $role, $id);
    }
    $stmt->execute();
    $stmt->close();
}

header('Location: dashboard_admin.php?menu=pengguna');
exit;