<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "makan_gratis";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Create distribusi_makanan table
$sql = "CREATE TABLE IF NOT EXISTS distribusi_makanan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    makanan_id INT NOT NULL,
    status_distribusi ENUM('Dijadwalkan', 'Dikirim', 'Diterima', 'Ditolak') DEFAULT 'Dijadwalkan',
    jadwal_kirim DATETIME NOT NULL,
    jumlah_terkirim INT,
    konfirmasi_penerima TEXT,
    waktu_konfirmasi DATETIME,
    catatan_petugas TEXT,
    waktu_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (makanan_id) REFERENCES makanan_kirim(id) ON DELETE CASCADE
)";
$conn->query($sql);
?>
