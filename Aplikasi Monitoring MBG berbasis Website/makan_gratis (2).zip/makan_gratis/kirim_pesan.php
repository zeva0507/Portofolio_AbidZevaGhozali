<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $penerima_id = intval($_POST['penerima_id']);
    $pengirim_id = $_SESSION['user_id'];
    $subjek = $_POST['subjek'];
    $isi = $_POST['isi'];
    $reply_to = isset($_POST['reply_to']) && $_POST['reply_to'] !== '' ? intval($_POST['reply_to']) : null;
    
    if ($reply_to === null) {
        $stmt = $conn->prepare("INSERT INTO pesan (pengirim_id, penerima_id, subjek, isi, reply_to) VALUES (?, ?, ?, ?, NULL)");
        $stmt->bind_param("iiss", $pengirim_id, $penerima_id, $subjek, $isi);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("INSERT INTO pesan (pengirim_id, penerima_id, subjek, isi, reply_to) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iissi", $pengirim_id, $penerima_id, $subjek, $isi, $reply_to);
        $stmt->execute();
        // Update status pesan asal menjadi Sudah Dibaca
        $update = $conn->prepare("UPDATE pesan SET status='Sudah Dibaca' WHERE id=?");
        $update->bind_param("i", $reply_to);
        $update->execute();
    }
    
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}
