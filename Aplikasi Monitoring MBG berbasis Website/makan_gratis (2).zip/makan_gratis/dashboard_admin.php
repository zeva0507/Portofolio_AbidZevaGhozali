<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

// Handle tambah/edit/hapus sekolah
if (isset($_POST['save_sekolah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $keterangan = $_POST['keterangan'];
    $jenjang = $_POST['jenjang'];
    $status_sekolah = $_POST['status_sekolah'];
    $alasan_belum = isset($_POST['alasan_belum']) ? $_POST['alasan_belum'] : '';
    if ($_POST['id'] == '') {
        // Tambah
        $username = uniqid('sekolah');
        $password = password_hash('12345', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO user (nama, alamat, keterangan, alasan_belum, jenjang, status_sekolah, role, username, password) VALUES (?, ?, ?, ?, ?, ?, 'sekolah', ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssssssss", $nama, $alamat, $keterangan, $alasan_belum, $jenjang, $status_sekolah, $username, $password);
            $stmt->execute();
            $stmt->close();
        } else {
            die("Error query: " . $conn->error);
        }
    } else {
        // Edit
        $stmt = $conn->prepare("UPDATE user SET nama=?, alamat=?, keterangan=?, alasan_belum=?, jenjang=?, status_sekolah=? WHERE id=?");
        if ($stmt) {
            $stmt->bind_param("ssssssi", $nama, $alamat, $keterangan, $alasan_belum, $jenjang, $status_sekolah, $_POST['id']);
            $stmt->execute();
            $stmt->close();
        } else {
            die("Error query: " . $conn->error);
        }
    }
    header("Location: dashboard_admin.php?menu=sekolah");
    exit;
}
if (isset($_GET['hapus_sekolah'])) {
    $id = intval($_GET['hapus_sekolah']);
    $conn->query("DELETE FROM user WHERE id=$id AND role='sekolah'");
    header("Location: dashboard_admin.php?menu=sekolah");
    exit;
}
$edit_sekolah = null;
if (isset($_GET['edit_sekolah'])) {
    $id = intval($_GET['edit_sekolah']);
    $res = $conn->query("SELECT * FROM user WHERE id=$id AND role='sekolah'");
    $edit_sekolah = $res->fetch_assoc();
}

// Handle tambah/edit/hapus makanan
if (isset($_POST['save_makanan'])) {
    $jumlah = intval($_POST['jumlah']);
    $sekolah_id = intval($_POST['sekolah_id']);
    $tanggal_kirim = $_POST['tanggal_kirim'];
    $lauk_menu = $_POST['lauk_menu'];

    // Ambil alamat sekolah dari tabel user
    $alamat = '';
    $getAlamat = $conn->prepare("SELECT alamat FROM user WHERE id=?");
    $getAlamat->bind_param("i", $sekolah_id);
    $getAlamat->execute();
    $getAlamat->bind_result($alamat);
    $getAlamat->fetch();
    $getAlamat->close();

    if ($_POST['id'] == '') {
        // Tambah
        $stmt = $conn->prepare("INSERT INTO makanan_kirim (jumlah, sekolah_id, tanggal_kirim, lauk_menu, alamat) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisss", $jumlah, $sekolah_id, $tanggal_kirim, $lauk_menu, $alamat);
        $stmt->execute();
        $stmt->close();
    } else {
        // Edit
        $stmt = $conn->prepare("UPDATE makanan_kirim SET jumlah=?, sekolah_id=?, tanggal_kirim=?, lauk_menu=?, alamat=? WHERE id=?");
        $stmt->bind_param("iisssi", $jumlah, $sekolah_id, $tanggal_kirim, $lauk_menu, $alamat, $_POST['id']);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: dashboard_admin.php?menu=makanan");
    exit;
}
if (isset($_GET['hapus_makanan'])) {
    $id = intval($_GET['hapus_makanan']);
    $conn->query("DELETE FROM makanan_kirim WHERE id=$id");
    header("Location: dashboard_admin.php?menu=makanan");
    exit;
}
$edit_makanan = null;
if (isset($_GET['edit_makanan'])) {
    $id = intval($_GET['edit_makanan']);
    $res = $conn->query("SELECT * FROM makanan_kirim WHERE id=$id");
    $edit_makanan = $res->fetch_assoc();
}

// Handle pengaduan: update status/hapus
if (isset($_POST['update_status_pengaduan'])) {
    $id = intval($_POST['id']);
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE pengaduan SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    header("Location: dashboard_admin.php?menu=pengaduan");
    exit;
}
if (isset($_GET['hapus_pengaduan'])) {
    $id = intval($_GET['hapus_pengaduan']);
    $conn->query("DELETE FROM pengaduan WHERE id=$id");
    header("Location: dashboard_admin.php?menu=pengaduan");
    exit;
}

// Handle tambah/edit/hapus pengaduan
if (isset($_POST['save_pengaduan'])) {
    $user_id = intval($_POST['user_id']);
    $isi = $_POST['isi'];
    $status = $_POST['status'];
        $komentar = isset($_POST['komentar']) ? $_POST['komentar'] : null;
    $foto = null;
    // Proses upload foto jika ada (hanya untuk tambah, bukan edit)
    if ($_POST['id'] == '' && isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nama_file = 'pengaduan_' . time() . '_' . rand(1000,9999) . '.' . $ext;
        $target_file = $target_dir . $nama_file;
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
            $foto = $nama_file;
        }
    }
    if ($_POST['id'] == '') {
        // Tambah
        $stmt = $conn->prepare("INSERT INTO pengaduan (user_id, isi, status, foto) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $user_id, $isi, $status, $foto);
        $stmt->execute();
    } else {
        // Edit, update komentar juga
        $stmt = $conn->prepare("UPDATE pengaduan SET user_id=?, isi=?, status=?, komentar=? WHERE id=?");
        $stmt->bind_param("isssi", $user_id, $isi, $status, $komentar, $_POST['id']);
        $stmt->execute();
    }
    header("Location: dashboard_admin.php?menu=pengaduan");
    exit;
}
$edit_pengaduan = null;
if (isset($_GET['edit_pengaduan'])) {
    $id = intval($_GET['edit_pengaduan']);
    $res = $conn->query("SELECT * FROM pengaduan WHERE id=$id");
    $edit_pengaduan = $res->fetch_assoc();
}
$user_all = $conn->query("SELECT * FROM user ORDER BY nama"); // untuk dropdown pelapor pengaduan

// Ambil data
// Perbaiki query ini agar kolom keterangan selalu ada (jika belum ada di database, tambahkan dulu kolomnya)
$user = $conn->query("SELECT * FROM user WHERE role='sekolah' ORDER BY nama");

// --- PAGINATION SETUP ---
$page_pengaduan = isset($_GET['page_pengaduan']) ? max(1, intval($_GET['page_pengaduan'])) : 1;
$page_sekolah = isset($_GET['page_sekolah']) ? max(1, intval($_GET['page_sekolah'])) : 1;
$page_makanan = isset($_GET['page_makanan']) ? max(1, intval($_GET['page_makanan'])) : 1;
$page_user = isset($_GET['page_user']) ? max(1, intval($_GET['page_user'])) : 1;
$limit = 5;
$offset_pengaduan = ($page_pengaduan - 1) * $limit;
$offset_sekolah = ($page_sekolah - 1) * $limit;
$offset_makanan = ($page_makanan - 1) * $limit;
$offset_user = ($page_user - 1) * $limit;

// Tambahkan filter query untuk pengaduan (sebelum query SELECT pengaduan)
$status_pengaduan_filter = isset($_GET['filter_status_pengaduan']) ? $_GET['filter_status_pengaduan'] : '';
$status_pengaduan_sql = '';
if ($status_pengaduan_filter && $status_pengaduan_filter != 'all') {
    $status_pengaduan_sql = " AND pengaduan.status = '".$conn->real_escape_string($status_pengaduan_filter)."' ";
}
$search_pengaduan_sql = '';
if (!empty($_GET['search'])) {
    $search_pengaduan = $conn->real_escape_string($_GET['search']);
    $search_pengaduan_sql = " AND user.nama LIKE '%$search_pengaduan%'";
}

// Data pengaduan untuk tabel Pengaduan
$pengaduan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql ORDER BY tanggal DESC LIMIT $limit OFFSET $offset_pengaduan");
$total_pengaduan = $conn->query("SELECT COUNT(*) as total FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql")->fetch_assoc()['total'];

// Data sekolah untuk tabel Data Sekolah 
$where = ["role='sekolah'"]; // Base condition

if (!empty($_GET['filter_jenjang'])) {
    $jenjang = $conn->real_escape_string($_GET['filter_jenjang']);
    $where[] = "jenjang='$jenjang'";
}

if (!empty($_GET['filter_status'])) {
    $status = $conn->real_escape_string($_GET['filter_status']);
    $where[] = "status_sekolah='$status'";
}

if (!empty($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $where[] = "(nama LIKE '%$search%' OR alamat LIKE '%$search%')";
}

$whereSql = implode(" AND ", $where);
$user = $conn->query("SELECT * FROM user WHERE $whereSql ORDER BY nama LIMIT $limit OFFSET $offset_sekolah");
$total_sekolah = $conn->query("SELECT COUNT(*) as total FROM user WHERE $whereSql")->fetch_assoc()['total'];

$user_sekolah = $conn->query("SELECT * FROM user WHERE role='sekolah' ORDER BY nama"); // untuk dropdown makanan
// Tambahkan search bar untuk menu makanan
$search_makanan = isset($_GET['search_makanan']) ? trim($_GET['search_makanan']) : '';
$search_makanan_sql = '';
if ($search_makanan !== '') {
    $search_val = $conn->real_escape_string($search_makanan);
    $search_makanan_sql = " AND (user.nama LIKE '%$search_val%' OR makanan_kirim.lauk_menu LIKE '%$search_val%' OR makanan_kirim.alamat LIKE '%$search_val%')";
}

// Data makanan untuk tabel Data Makanan ke Sekolah (gunakan search)
$makanan = $conn->query("SELECT makanan_kirim.*, user.nama as sekolah_nama FROM makanan_kirim LEFT JOIN user ON makanan_kirim.sekolah_id=user.id WHERE 1=1 $search_makanan_sql ORDER BY tanggal_kirim DESC LIMIT $limit OFFSET $offset_makanan");
$total_makanan = $conn->query("SELECT COUNT(*) as total FROM makanan_kirim LEFT JOIN user ON makanan_kirim.sekolah_id=user.id WHERE 1=1 $search_makanan_sql")->fetch_assoc()['total'];

$total_user = $conn->query("SELECT COUNT(*) as total FROM user")->fetch_assoc()['total'];
$users = $conn->query("SELECT * FROM user ORDER BY role, nama LIMIT $limit OFFSET $offset_user");

// Menu aktif
$menu = isset($_GET['menu']) ? $_GET['menu'] : 'pengaduan';

// Tambahkan inisialisasi variabel filter sebelum HTML agar tidak undefined
$status_pengaduan_filter = isset($_GET['filter_status_pengaduan']) ? $_GET['filter_status_pengaduan'] : '';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="includes/action_buttons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --arya-green: #00512C;
            --arya-dark: #004024;
            --arya-light: #F5F5F5;
            --arya-gray: #707070;
            --arya-border: #E5E5E5;
        }

        body {
            background: var(--arya-light);
            font-family: 'Poppins', sans-serif !important;
        }

        table, .table, .table th, .table td {
            font-family: 'Poppins', sans-serif !important;
            font-size: 14px !important;
        }
        .table th, th {
            font-weight: 600 !important;
            color: #2c3e50;
        }
        .table td, td {
            font-weight: 400 !important;
            color: #333;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: var(--arya-green);
            padding: 25px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
        }

        .sidebar .logo-section {
            padding-bottom: 25px;
            margin-bottom: 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar .logo-section img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            padding: 10px;
            background: rgba(255,255,255,0.1);
            margin-bottom: 15px;
        }

        .sidebar .logo-section .title {
            color: #fff;
            font-size: 20px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sidebar .logo-section .name {
            color: #fff;
            font-size: 16px;
            font-weight: 400;
            margin-top: 5px;
            display: block;
        }

        .sidebar .menu-section a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            font-size: 15px;
            border-radius: 6px;
            margin-bottom: 8px;
            transition: all 0.3s ease;
        }

        .sidebar .menu-section a:hover,
        .sidebar .menu-section a.active {
            background: rgba(255,255,255,0.1);
            color: #fff;
        }

        .sidebar .menu-section .logout-btn {
            margin-top: 20px;
            background: rgba(255,255,255,0.1);
            text-align: center;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .section-title {
            font-size: 24px;
            font-weight: 500;
            color: var(--arya-green);
            margin: 30px 0 20px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .card {
            background: #fff;
            border-radius: 8px;
            border: 1px solid var(--arya-border);
            padding: 25px;
            margin-bottom: 25px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
        }

        .table {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 81, 44, 0.1);
            border: 1px solid var(--arya-border);
            margin-bottom: 30px;
        }

        .table thead th {
            background: var(--arya-green) !important;
            color: #fff !important;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
            padding: 15px;
            border: none;
            white-space: nowrap;
        }

        .table tbody td {
            padding: 15px;
            color: var(--arya-dark);
            font-size: 14px;
            border-bottom: 1px solid var(--arya-border);
            vertical-align: middle;
            transition: all 0.2s ease;
        }

        .table tbody tr:hover {
            background-color: rgba(0, 81, 44, 0.05);
            cursor: pointer;
        }

        .table-striped > tbody > tr:nth-of-type(odd) {
            background-color: rgba(0, 81, 44, 0.02);
        }

        .table-bordered th,
        .table-bordered td {
            border-color: rgba(0, 81, 44, 0.1);
        }

        /* Add this for the regular table without Bootstrap classes */
        #table-sekolah,
        #table-makanan,
        #table-laporan {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 81, 44, 0.1);
            border: 1px solid var(--arya-border);
            margin-bottom: 30px;
        }

        #table-sekolah th,
        #table-makanan th,
        #table-laporan th {
            background: var(--arya-green);
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
            padding: 15px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        #table-sekolah td,
        #table-makanan td,
        #table-laporan td {
            padding: 15px;
            color: var(--arya-dark);
            font-size: 14px;
            border: 1px solid var(--arya-border);
            background: #fff;
        }

        #table-sekolah tr:hover td,
        #table-makanan tr:hover td,
        #table-laporan tr:hover td {
            background-color: rgba(0, 81, 44, 0.05);
        }

        .btn-login, 
        button[type="submit"] {
            background: var(--arya-green);
            color: #fff;
            border: none;
            padding: 12px 28px;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-login:hover,
        button[type="submit"]:hover {
            background: #006d3b;
        }

        .form-admin {
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            border: 1px solid var(--arya-border);
        }

        .form-admin input,
        .form-admin select,
        .form-admin textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid var(--arya-border);
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-admin input:focus,
        .form-admin select:focus,
        .form-admin textarea:focus {
            border-color: var(--arya-green);
            outline: none;
        }

        .form-admin label {
            display: block;
            margin-bottom: 8px;
            color: var(--arya-green);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .action-btn {
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-radius: 4px;
            transition: all 0.3s ease;
        }

        .edit-btn {
            background: rgba(0, 81, 44, 0.1);
            color: var(--arya-green);
        }

        .hapus-btn {
            background: rgba(220, 38, 38, 0.1);
            color: #DC2626;
        }

        .banner-makan-gratis {
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            border: 1px solid var(--arya-border);
            margin-bottom: 30px;
        }

        .banner-title {
            color: var(--arya-green);
            font-size: 20px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }

        .banner-desc {
            color: var(--arya-gray);
            font-size: 14px;
            line-height: 1.6;
        }

        .chat-card {
            border: none;
            box-shadow: 0 0 20px rgba(0,0,0,0.08);
            border-radius: 12px;
        }
        
        .chat-table thead th {
            background: var(--arya-green);
            color: white;
            padding: 15px;
            font-weight: 500;
        }
        
        .chat-avatar {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
            border-radius: 50%;
        }
        
        .chat-avatar i {
            font-size: 20px;
        }
        
        .message-modal .modal-content {
            border: none;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        .message-header {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .message-content {
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            border: 1px solid #eee;
        }
        
        .btn-outline-primary,
        .btn-outline-success {
            border-width: 2px;
            font-weight: 500;
            padding: 4px 12px;
        }
        
        .btn-outline-primary:hover,
        .btn-outline-success:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="sidebar">
        <div class="logo-section">
            <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Logo Admin">
            <div class="title">
                Dashboard Admin<br>
                <span class="name"><?= htmlspecialchars($_SESSION['nama']) ?></span>
            </div>
        </div>
        <div class="menu-section">
            <a href="?menu=pengaduan" class="<?= $menu=='pengaduan'?'active':'' ?>">Pengaduan</a>
            <a href="?menu=sekolah" class="<?= $menu=='sekolah'?'active':'' ?>">Data Sekolah</a>
            <a href="?menu=makanan" class="<?= $menu=='makanan'?'active':'' ?>">Data Makanan ke Sekolah</a>
            <a href="?menu=komunikasi" class="<?= $menu=='komunikasi'?'active':'' ?>">Portal Komunikasi</a>
            <a href="?menu=pengguna" class="<?= $menu=='pengguna'?'active':'' ?>">Data User</a> <!-- New menu -->
            <a href="?menu=cetak_laporan" class="<?= $menu=='cetak_laporan'?'active':'' ?>">Cetak Laporan</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="main-content">
        <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white d-flex align-items-center" style="border-left: 6px solid var(--arya-green);">
            <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:#fff;border-radius:50%;padding:10px;border:6px solid var(--arya-green);">
            <div>
                <div class="fw-bold" style="font-size:1.5rem;color:var(--arya-green);">Program Makan Siang Gratis</div>
                <div style="color:var(--arya-gray);font-weight:500;">Pantau distribusi makanan dan pengaduan melalui dashboard admin ini</div>
            </div>
        </div>

        <?php if ($menu=='cetak_laporan'): ?>
            <h3 class="section-title">Cetak Laporan</h3>
            <form method="get" style="margin-bottom:18px;">
                <input type="hidden" name="menu" value="cetak_laporan">
                <select name="laporan" required style="padding:8px 14px; border-radius:6px; border:1.5px solid #b2d8b2; font-size:1.05rem;">
                    <option value="">Pilih Data Laporan</option>
                    <option value="sekolah" <?= (isset($_GET['laporan']) && $_GET['laporan']=='sekolah')?'selected':'' ?>>Data Sekolah</option>
                    <option value="pengaduan" <?= (isset($_GET['laporan']) && $_GET['laporan']=='pengaduan')?'selected':'' ?>>Pengaduan</option>
                    <option value="makanan" <?= (isset($_GET['laporan']) && $_GET['laporan']=='makanan')?'selected':'' ?>>Data Makanan ke Sekolah</option>
                    <option value="komunikasi" <?= (isset($_GET['laporan']) && $_GET['laporan']=='komunikasi')?'selected':'' ?>>Portal Komunikasi</option>
                </select>
                <button type="submit" class="btn-login" style="width:auto;padding:8px 18px;margin-left:8px;">Tampilkan</button>
            </form>
            <?php if (isset($_GET['laporan']) && $_GET['laporan']=='sekolah'): ?>
                <h3 class="section-title">Laporan Data Sekolah</h3>
                <?php $laporan = $conn->query("SELECT * FROM user WHERE role='sekolah' ORDER BY nama"); ?>
                <table id="table-laporan" border="1" cellpadding="6" cellspacing="0" style="width:100%">
                    <tr>
                        <th>Nama Sekolah</th>
                        <th>Alamat</th>
                        <th>Jenjang</th>
                        <th>Status Sekolah</th>
                        <th>Keterangan MBG</th>
                        <th>Alasan Belum MBG</th>
                    </tr>
                    <?php while($row = $laporan->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['nama']) ?></td>
                        <td><?= htmlspecialchars($row['alamat']) ?></td>
                        <td><?= isset($row['jenjang']) ? htmlspecialchars($row['jenjang']) : '-' ?></td>
                        <td><?= isset($row['status_sekolah']) ? htmlspecialchars($row['status_sekolah']) : '-' ?></td>
                        <td><?= isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                        <td><?= ($row['keterangan']=='Belum') ? htmlspecialchars($row['alasan_belum']) : '-' ?></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
                <button onclick="printTable('table-laporan')" class="btn-login" style="width:auto;margin:16px 0;">Cetak Laporan</button>
            <?php elseif (isset($_GET['laporan']) && $_GET['laporan']=='pengaduan'): ?>
                <h3 class="section-title">Laporan Pengaduan</h3>
                <?php
                // Ambil data pengaduan beserta foto dan komentar
                $laporan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id ORDER BY tanggal DESC");
                ?>
                <table id="table-laporan" border="1" cellpadding="6" cellspacing="0" style="width:100%">
                    <tr>
                        <th>Pelapor</th>
                        <th>Isi Pengaduan</th>
                        <th>Bukti Foto</th>
                        <th>Komentar</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                    <?php while($row = $laporan->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['pelapor']) ?></td>
                        <td><?= htmlspecialchars($row['isi']) ?></td>
                        <td>
                            <?php if (!empty($row['foto'])): ?>
                                <a href="uploads/<?= htmlspecialchars($row['foto']) ?>" target="_blank">
                                    <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="foto" style="max-width:70px;max-height:70px;border-radius:6px;">
                                </a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= !empty($row['komentar']) ? nl2br(htmlspecialchars($row['komentar'])) : '<span class="text-muted">-</span>' ?>
                        </td>
                        <td><?= htmlspecialchars($row['tanggal']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
                <button onclick="printTable('table-laporan')" class="btn-login" style="width:auto;margin:16px 0;">Cetak Laporan</button>
            <?php elseif (isset($_GET['laporan']) && $_GET['laporan']=='makanan'): ?>
                <h3 class="section-title">Laporan Data Makanan ke Sekolah</h3>
                <?php $laporan = $conn->query("SELECT makanan_kirim.*, user.nama as sekolah_nama FROM makanan_kirim LEFT JOIN user ON makanan_kirim.sekolah_id=user.id ORDER BY tanggal_kirim DESC"); ?>
                <table id="table-laporan" border="1" cellpadding="6" cellspacing="0" style="width:100%">
                    <tr>
                        <th>No</th>
                        <th>Nama Sekolah</th>
                        <th>Alamat</th>
                        <th>Lauk/Menu</th>
                        <th>Tanggal</th>
                        <th>Jumlah</th>
                    </tr>
                    <?php $no=1; while($row = $laporan->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['sekolah_nama']) ?></td>
                        <td><?= htmlspecialchars($row['alamat'] ?? '') ?></td>
                        <td><?= htmlspecialchars($row['lauk_menu'] ?? '') ?></td>
                        <td><?= htmlspecialchars($row['tanggal_kirim']) ?></td>
                        <td><?= htmlspecialchars($row['jumlah']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
                <button onclick="printTable('table-laporan')" class="btn-login" style="width:auto;margin:16px 0;">Cetak Laporan</button>
            <?php elseif (isset($_GET['laporan']) && $_GET['laporan']=='komunikasi'): ?>
                <h3 class="section-title">Laporan Portal Komunikasi</h3>
                <?php
                $laporan = $conn->query("SELECT p.*, u1.nama as pengirim, u2.nama as penerima FROM pesan p LEFT JOIN user u1 ON p.pengirim_id=u1.id LEFT JOIN user u2 ON p.penerima_id=u2.id ORDER BY p.tanggal DESC");
                ?>
                <table id="table-laporan" border="1" cellpadding="6" cellspacing="0" style="width:100%">
                    <tr>
                        <th>No</th>
                        <th>Pengirim</th>
                        <th>Penerima</th>
                        <th>Subjek</th>
                        <th>Isi Pesan</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                    <?php $no=1; while($row = $laporan->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['pengirim']) ?></td>
                        <td><?= htmlspecialchars($row['penerima']) ?></td>
                        <td><?= htmlspecialchars($row['subjek']) ?></td>
                        <td><?= nl2br(htmlspecialchars($row['isi'])) ?></td>
                        <td><?= htmlspecialchars($row['tanggal']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
                <button onclick="printTable('table-laporan')" class="btn-login" style="width:auto;margin:16px 0;">Cetak Laporan</button>
            <?php endif; ?>
        <?php elseif ($menu=='pengaduan'): ?>
            <!-- Add button -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="section-title mb-0">Data Pengaduan</h3>
            </div>
    <!-- Filter Form: Select Status + Search -->
    <form method="get" class="row g-2 mb-3 align-items-center">
        <input type="hidden" name="menu" value="pengaduan">
        <div class="col-md-3">
            <select name="filter_status_pengaduan" class="form-select" onchange="this.form.submit()">
                <option value="all" <?= $status_pengaduan_filter=='all'||$status_pengaduan_filter==''?'selected':'' ?>>Semua Status</option>
                <option value="Belum Diproses" <?= $status_pengaduan_filter=='Belum Diproses'?'selected':'' ?>>Belum Diproses</option>
                <option value="Diproses" <?= $status_pengaduan_filter=='Diproses'?'selected':'' ?>>Diproses</option>
                <option value="Selesai" <?= $status_pengaduan_filter=='Selesai'?'selected':'' ?>>Selesai</option>
            </select>
        </div>
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Cari nama pelapor..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        </div>
        <div class="col-md-2 d-grid">
            <button type="submit" class="btn btn-success">Filter</button>
        </div>
    </form>

            <!-- Modal Form -->
            <div class="modal fade" id="formPengaduan" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?= $edit_pengaduan ? 'Edit' : 'Tambah' ?> Pengaduan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <!-- Tambahkan enctype untuk upload file -->
                            <form method="post" id="form-pengaduan" enctype="multipart/form-data">
                                <input type="hidden" name="id" value="<?= $edit_pengaduan ? $edit_pengaduan['id'] : '' ?>">
                                <!-- Hapus dropdown user_id, ganti dengan tampilan nama pelapor saja -->
                                <?php if ($edit_pengaduan): ?>
                                    <div class="mb-3">
                                        <label class="form-label">Pelapor (User)</label>
                                        <input type="text" class="form-control" value="<?php
                                            $uid = $edit_pengaduan['user_id'];
                                            $uname = '';
                                            foreach ($user_all as $u) {
                                                if ($u['id'] == $uid) {
                                                    $uname = $u['nama'] . ' (' . $u['role'] . ')';
                                                    break;
                                                }
                                            }
                                            echo htmlspecialchars($uname);
                                        ?>" readonly>
                                        <input type="hidden" name="user_id" value="<?= $edit_pengaduan['user_id'] ?>">
                                    </div>
                                <?php endif; ?>
                                <div class="mb-3">
                                    <label class="form-label">Isi Pengaduan</label>
                                    <textarea name="isi" class="form-control" required rows="4" readonly><?= $edit_pengaduan ? htmlspecialchars($edit_pengaduan['isi']) : '' ?></textarea>
                                    <small class="text-danger">Teks ini tidak dapat diubah</small>
                                </div>
                                <?php if (!$edit_pengaduan): ?>
                                <div class="mb-3">
                                    <label class="form-label">Foto (opsional)</label>
                                    <input type="file" name="foto" class="form-control" accept="image/*">
                                </div>
                                <?php endif; ?>
                                <?php if ($edit_pengaduan): ?>
                                <div class="mb-3">
                                    <label class="form-label">Komentar (Admin)</label>
                                    <textarea name="komentar" class="form-control" rows="3"><?= htmlspecialchars($edit_pengaduan['komentar'] ?? '') ?></textarea>
                                </div>
                                <?php endif; ?>
                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select">
                                        <option <?= !$edit_pengaduan || $edit_pengaduan['status']=='Belum Diproses'?'selected':'' ?>>Belum Diproses</option>
                                        <option <?= $edit_pengaduan && $edit_pengaduan['status']=='Diproses'?'selected':'' ?>>Diproses</option>
                                        <option <?= $edit_pengaduan && $edit_pengaduan['status']=='Selesai'?'selected':'' ?>>Selesai</option>
                                    </select>
                                </div>
                                <div class="text-end">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" name="save_pengaduan" class="btn btn-success">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table section -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle bg-white">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Pelapor</th>
                            <th>Isi Pengaduan</th>
                            <th>Bukti Foto</th>
                            <th>Komentar</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $no = 1 + $offset_pengaduan; while($row = $pengaduan->fetch_assoc()): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['pelapor']) ?></td>
                            <td><?= htmlspecialchars($row['isi']) ?></td>
                            <td>
                                <?php if (!empty($row['foto'])): ?>
                                    <a href="uploads/<?= htmlspecialchars($row['foto']) ?>" target="_blank">
                                        <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="foto" style="max-width:70px;max-height:70px;border-radius:6px;">
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= !empty($row['komentar']) ? nl2br(htmlspecialchars($row['komentar'])) : '<span class="text-muted">-</span>' ?>
                            </td>
                            <td><?= htmlspecialchars($row['tanggal']) ?></td>
                            <td><?= htmlspecialchars($row['status']) ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?menu=pengaduan&edit_pengaduan=<?= $row['id'] ?>" class="btn-edit">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            $total_pages_pengaduan = ceil($total_pengaduan / $limit);
            if ($total_pages_pengaduan > 1): ?>
            <nav>
              <ul class="pagination justify-content-center">
                <li class="page-item<?= $page_pengaduan == 1 ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan-1 ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_pages_pengaduan; $i++): ?>
                  <li class="page-item<?= $page_pengaduan == $i ? ' active' : '' ?>">
                    <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $i ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item<?= $page_pengaduan == $total_pages_pengaduan ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan+1 ?>">Next</a>
                </li>
              </ul>
            </nav>
            <?php endif; ?>
        <?php elseif ($menu=='sekolah'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="section-title mb-0">Data Sekolah</h3>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formSekolah">
                    <i class="fas fa-plus"></i> Tambah Data Sekolah
                </button>
            </div>
            <!-- Modal Form -->
            <div class="modal fade" id="formSekolah" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?= $edit_sekolah ? 'Edit' : 'Tambah' ?> Data Sekolah</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form method="post" id="form-sekolah">
                                <input type="hidden" name="id" value="<?= $edit_sekolah ? $edit_sekolah['id'] : '' ?>">
                                <div class="mb-3">
                                    <label class="form-label">Nama Sekolah</label>
                                    <input type="text" name="nama" class="form-control" required value="<?= $edit_sekolah ? htmlspecialchars($edit_sekolah['nama']) : '' ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Alamat</label>
                                    <input type="text" name="alamat" class="form-control" required value="<?= $edit_sekolah && isset($edit_sekolah['alamat']) ? htmlspecialchars($edit_sekolah['alamat']) : '' ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Jenjang</label>
                                    <select name="jenjang" class="form-select" required>
                                        <option value="">Pilih Jenjang</option>
                                        <option value="SD" <?= $edit_sekolah && isset($edit_sekolah['jenjang']) && $edit_sekolah['jenjang']=='SD'?'selected':'' ?>>SD</option>
                                        <option value="SMP" <?= $edit_sekolah && isset($edit_sekolah['jenjang']) && $edit_sekolah['jenjang']=='SMP'?'selected':'' ?>>SMP</option>
                                        <option value="SMA" <?= $edit_sekolah && isset($edit_sekolah['jenjang']) && $edit_sekolah['jenjang']=='SMA'?'selected':'' ?>>SMA</option>
                                        <option value="SMK" <?= $edit_sekolah && isset($edit_sekolah['jenjang']) && $edit_sekolah['jenjang']=='SMK'?'selected':'' ?>>SMK</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Status Sekolah</label>
                                    <select name="status_sekolah" class="form-select" required>
                                        <option value="">Pilih Status</option>
                                        <option value="Negeri" <?= $edit_sekolah && isset($edit_sekolah['status_sekolah']) && $edit_sekolah['status_sekolah']=='Negeri'?'selected':'' ?>>Negeri</option>
                                        <option value="Swasta" <?= $edit_sekolah && isset($edit_sekolah['status_sekolah']) && $edit_sekolah['status_sekolah']=='Swasta'?'selected':'' ?>>Swasta</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Keterangan MBG</label>
                                    <select name="keterangan" id="keterangan_mbg" class="form-select" required onchange="toggleAlasanBelum()">
                                        <option value="Sudah" <?= $edit_sekolah && isset($edit_sekolah['keterangan']) && $edit_sekolah['keterangan']=='Sudah'?'selected':'' ?>>Sudah</option>
                                        <option value="Belum" <?= $edit_sekolah && isset($edit_sekolah['keterangan']) && $edit_sekolah['keterangan']=='Belum'?'selected':'' ?>>Belum</option>
                                    </select>
                                </div>
                                <div class="mb-3" id="alasan_belum_wrap" style="display:<?= ($edit_sekolah && isset($edit_sekolah['keterangan']) && $edit_sekolah['keterangan']=='Belum') ? 'block':'none' ?>;">
                                    <label class="form-label">Alasan Belum MBG</label>
                                    <input type="text" name="alasan_belum" class="form-control" id="alasan_belum" value="<?= $edit_sekolah && isset($edit_sekolah['alasan_belum']) ? htmlspecialchars($edit_sekolah['alasan_belum']) : '' ?>">
                                </div>
                                <div class="text-end">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" name="save_sekolah" class="btn btn-success">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filter & Search -->
            <form method="get" style="margin-bottom:16px;display:flex;gap:10px;flex-wrap:wrap;">
                <input type="hidden" name="menu" value="sekolah">
                <select name="filter_jenjang">
                    <option value="">Semua Jenjang</option>
                    <option value="SD" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SD'?'selected':'' ?>>SD</option>
                    <option value="SMP" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMP'?'selected':'' ?>>SMP</option>
                    <option value="SMA" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMA'?'selected':'' ?>>SMA</option>
                    <option value="SMK" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMK'?'selected':'' ?>>SMK</option>
                </select>
                <select name="filter_status">
                    <option value="">Semua Status</option>
                    <option value="Negeri" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Negeri'?'selected':'' ?>>Negeri</option>
                    <option value="Swasta" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Swasta'?'selected':'' ?>>Swasta</option>
                </select>
                <input type="text" name="search" placeholder="Cari nama/alamat..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>" style="min-width:180px;">
                <button type="submit" class="btn-login" style="width:auto;padding:6px 18px;">Filter</button>
                <?php if (isset($_GET['filter_jenjang']) || isset($_GET['filter_status']) || isset($_GET['search'])): ?>
                    <a href="dashboard_admin.php?menu=sekolah" style="margin-left:8px;">Reset</a>
                <?php endif; ?>
            </form>

            <!-- Table section -->
            <div class="table-responsive">
                <table id="table-sekolah" border="1" cellpadding="6" cellspacing="0" style="width:100%">
                    <tr>
                        <th>No</th>
                        <th>Nama Sekolah</th>
                        <th>Alamat</th>
                        <th>Jenjang</th>
                        <th>Status Sekolah</th>
                        <th>Keterangan MBG</th>
                        <th>Alasan Belum MBG</th>
                        <th>Aksi</th>
                    </tr>
                    <?php $no = 1 + $offset_sekolah; while($row = $user->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['nama']) ?></td>
                        <td><?= htmlspecialchars($row['alamat']) ?></td>
                        <td><?= isset($row['jenjang']) ? htmlspecialchars($row['jenjang']) : '-' ?></td>
                        <td><?= isset($row['status_sekolah']) ? htmlspecialchars($row['status_sekolah']) : '-' ?></td>
                        <td><?= isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                        <td><?= ($row['keterangan']=='Belum') ? htmlspecialchars($row['alasan_belum']) : '-' ?></td>
                        <td>
                            <div class="action-buttons">
                                <a href="?menu=sekolah&edit_sekolah=<?= $row['id'] ?>" class="btn-edit">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </div>
            <?php
            $total_pages_sekolah = ceil($total_sekolah / $limit);
            if ($total_pages_sekolah > 1): ?>
            <nav>
              <ul class="pagination justify-content-center">
                <li class="page-item<?= $page_sekolah == 1 ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah-1 ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_pages_sekolah; $i++): ?>
                  <li class="page-item<?= $page_sekolah == $i ? ' active' : '' ?>">
                    <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $i ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item<?= $page_sekolah == $total_pages_sekolah ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah+1 ?>">Next</a>
                </li>
              </ul>
            </nav>
            <?php endif; ?>
        <?php elseif ($menu=='makanan'): ?>
            <!-- Add button -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="section-title mb-0">Data Makanan ke Sekolah</h3>
            </div>

            <!-- Search Bar -->
            <form method="get" class="row g-2 mb-3 align-items-center">
                <input type="hidden" name="menu" value="makanan">
                <div class="col-md-6">
                    <input type="text" name="search_makanan" class="form-control" placeholder="Cari sekolah/menu/alamat..." value="<?= htmlspecialchars($search_makanan) ?>">
                </div>
                <div class="col-md-2 d-grid">
                    <button type="submit" class="btn btn-success">Cari</button>
                </div>
            </form>

            <!-- Modal Form -->
            <div class="modal fade" id="formMakanan" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?= $edit_makanan ? 'Edit' : 'Tambah' ?> Data Makanan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form method="post" id="form-makanan">
                                <input type="hidden" name="id" value="<?= $edit_makanan ? $edit_makanan['id'] : '' ?>">
                                <div class="mb-3">
                                    <label class="form-label">Nama Sekolah</label>
                                    <select name="sekolah_id" id="sekolah_id" class="form-select" required>
                                        <option value="">Pilih Sekolah</option>
                                        <?php
                                        $jsAlamat = [];
                                        while($s = $user_sekolah->fetch_assoc()):
                                            $jsAlamat[$s['id']] = $s['alamat'];
                                        ?>
                                            <option value="<?= $s['id'] ?>" <?= $edit_makanan && $edit_makanan['sekolah_id']==$s['id']?'selected':'' ?>>
                                                <?= htmlspecialchars($s['nama']) ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Alamat Sekolah</label>
                                    <input type="text" name="alamat" id="alamat_sekolah" class="form-control" readonly 
                                           value="<?= $edit_makanan ? htmlspecialchars($edit_makanan['alamat']) : '' ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Lauk/Menu</label>
                                    <input type="text" name="lauk_menu" class="form-control" required 
                                           value="<?= $edit_makanan ? htmlspecialchars($edit_makanan['lauk_menu']) : '' ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tanggal</label>
                                    <input type="date" name="tanggal_kirim" class="form-control" required 
                                           value="<?= $edit_makanan ? htmlspecialchars($edit_makanan['tanggal_kirim']) : '' ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Jumlah</label>
                                    <input type="number" name="jumlah" class="form-control" required 
                                           value="<?= $edit_makanan ? htmlspecialchars($edit_makanan['jumlah']) : '' ?>">
                                </div>
                                <div class="text-end">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" name="save_makanan" class="btn btn-success">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table section -->
            <div class="table-responsive">
                <table id="table-makanan" class="table table-bordered table-striped align-middle bg-white">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Sekolah</th>
                            <th>Alamat</th>
                            <th>Lauk/Menu</th>
                            <th>Tanggal</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php   
                    $no = 1 + $offset_makanan;
                    while($row = $makanan->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['sekolah_nama']) ?></td>
                        <td><?= htmlspecialchars($row['alamat'] ?? '') ?></td>
                        <td><?= htmlspecialchars($row['lauk_menu'] ?? '') ?></td>
                        <td><?= htmlspecialchars($row['tanggal_kirim']) ?></td>
                        <td><?= htmlspecialchars($row['jumlah']) ?></td>
                        <td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            $total_pages_makanan = ceil($total_makanan / $limit);
            if ($total_pages_makanan > 1): ?>
            <nav>
              <ul class="pagination justify-content-center">
                <li class="page-item<?= $page_makanan == 1 ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=makanan&page_makanan=<?= $page_makanan-1 ?>&search_makanan=<?= urlencode($search_makanan) ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_pages_makanan; $i++): ?>
                  <li class="page-item<?= $page_makanan == $i ? ' active' : '' ?>">
                    <a class="page-link" href="?menu=makanan&page_makanan=<?= $i ?>&search_makanan=<?= urlencode($search_makanan) ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item<?= $page_makanan == $total_pages_makanan ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=makanan&page_makanan=<?= $page_makanan+1 ?>&search_makanan=<?= urlencode($search_makanan) ?>">Next</a>
                </li>
              </ul>
            </nav>
            <?php endif; ?>
        <?php elseif ($menu=='komunikasi'): ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="section-title mb-0">Portal Komunikasi</h3>
    </div>

    <!-- Filter by Status -->
    <form method="get" class="row g-2 mb-3 align-items-center">
        <input type="hidden" name="menu" value="komunikasi">
        <div class="col-md-3">
            <select name="filter_status_pesan" class="form-select" onchange="this.form.submit()">
                <option value="all" <?= (!isset($_GET['filter_status_pesan']) || $_GET['filter_status_pesan']=='all')?'selected':'' ?>>Semua Status</option>
                <option value="Belum Dibaca" <?= (isset($_GET['filter_status_pesan']) && $_GET['filter_status_pesan']=='Belum Dibaca')?'selected':'' ?>>Belum Dibaca</option>
                <option value="Sudah Dibaca" <?= (isset($_GET['filter_status_pesan']) && $_GET['filter_status_pesan']=='Sudah Dibaca')?'selected':'' ?>>Sudah Dibaca</option>
            </select>
        </div>
    </form>

    <div class="card chat-card">
        <div class="card-body px-0">
            <div class="table-responsive">
                <table class="table chat-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Pengirim</th>
                            <th>Subjek</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // PAGINATION SETUP
                        $page_komunikasi = isset($_GET['page_komunikasi']) ? max(1, intval($_GET['page_komunikasi'])) : 1;
                        $limit_komunikasi = 5;
                        $offset_komunikasi = ($page_komunikasi - 1) * $limit_komunikasi;

                        // Filter status pesan
                        $filter_status_pesan = isset($_GET['filter_status_pesan']) ? $_GET['filter_status_pesan'] : 'all';
                        $status_pesan_sql = '';
                        if ($filter_status_pesan && $filter_status_pesan != 'all') {
                            $status_pesan_sql = " AND p.status = '".$conn->real_escape_string($filter_status_pesan)."' ";
                        }

                        $total_pesan_komunikasi = $conn->query("SELECT COUNT(*) as total FROM pesan p WHERE p.penerima_id = {$_SESSION['user_id']} $status_pesan_sql")->fetch_assoc()['total'];
                        $pesan = $conn->query("
                            SELECT p.*, u.nama as pengirim,
                            (SELECT COUNT(*) FROM pesan WHERE reply_to = p.id) as has_reply
                            FROM pesan p 
                            JOIN user u ON p.pengirim_id = u.id 
                            WHERE p.penerima_id = {$_SESSION['user_id']} $status_pesan_sql
                            ORDER BY p.tanggal DESC
                            LIMIT $limit_komunikasi OFFSET $offset_komunikasi
                        ");
                        $no = 1 + $offset_komunikasi;
                        while($p = $pesan->fetch_assoc()):
                            $status = ($p['has_reply'] > 0) ? 'Sudah Dibaca' : 'Belum Dibaca';
                            if ($p['status'] != $status) {
                                $stmt = $conn->prepare("UPDATE pesan SET status = ? WHERE id = ?");
                                $stmt->bind_param("si", $status, $p['id']);
                                $stmt->execute();
                                $stmt->close();
                            }
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="chat-avatar">
                                        <i class="fas fa-user-circle text-secondary"></i>
                                    </div>
                                    <div class="ms-3">
                                        <?= htmlspecialchars($p['pengirim']) ?>
                                    </div>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($p['subjek']) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($p['tanggal'])) ?></td>
                            <td>
                                <span class="badge bg-<?= ($p['has_reply'] > 0)?'success':'warning' ?>">
                                    <?= $status ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary" onclick="bacaPesan(<?= $p['id'] ?>)">
                                    <i class="fas fa-envelope-open"></i> Baca
                                </button>
                                <button class="btn btn-sm btn-outline-success" onclick="balasPesan(<?= $p['id'] ?>, '<?= htmlspecialchars($p['pengirim']) ?>', <?= $p['pengirim_id'] ?>)">
                                    <i class="fas fa-reply"></i> Balas
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            $total_pages_komunikasi = ceil($total_pesan_komunikasi / $limit_komunikasi);
            if ($total_pages_komunikasi > 1): ?>
            <nav>
              <ul class="pagination justify-content-center mt-3">
                <li class="page-item<?= $page_komunikasi == 1 ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=komunikasi&page_komunikasi=<?= $page_komunikasi-1 ?>&filter_status_pesan=<?= urlencode($filter_status_pesan) ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_pages_komunikasi; $i++): ?>
                  <li class="page-item<?= $page_komunikasi == $i ? ' active' : '' ?>">
                    <a class="page-link" href="?menu=komunikasi&page_komunikasi=<?= $i ?>&filter_status_pesan=<?= urlencode($filter_status_pesan) ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item<?= $page_komunikasi == $total_pages_komunikasi ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=komunikasi&page_komunikasi=<?= $page_komunikasi+1 ?>&filter_status_pesan=<?= urlencode($filter_status_pesan) ?>">Next</a>
                </li>
              </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
<?php elseif ($menu=='pengguna'): ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="section-title mb-0">Data User</h3>
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formTambahUser">
            <i class="fas fa-plus"></i> Tambah User
        </button>
    </div>

    <!-- Filter by Role -->
    <form method="get" class="row g-2 mb-3 align-items-center">
        <input type="hidden" name="menu" value="pengguna">
        <div class="col-md-3">
            <select name="filter_role" class="form-select" onchange="this.form.submit()">
                <option value="all" <?= (!isset($_GET['filter_role']) || $_GET['filter_role']=='all')?'selected':'' ?>>Semua Role</option>
                <option value="admin" <?= (isset($_GET['filter_role']) && $_GET['filter_role']=='admin')?'selected':'' ?>>Admin</option>
                <option value="sekolah" <?= (isset($_GET['filter_role']) && $_GET['filter_role']=='sekolah')?'selected':'' ?>>Sekolah</option>
                <option value="petugas" <?= (isset($_GET['filter_role']) && $_GET['filter_role']=='petugas')?'selected':'' ?>>Petugas</option>
                <option value="pengguna" <?= (isset($_GET['filter_role']) && $_GET['filter_role']=='pengguna')?'selected':'' ?>>Pengguna</option>
            </select>
        </div>
    </form>

    <?php
    // Filter role untuk query users
    $filter_role = isset($_GET['filter_role']) ? $_GET['filter_role'] : 'all';
    $role_sql = '';
    if ($filter_role && $filter_role != 'all') {
        $role_sql = "WHERE role = '".$conn->real_escape_string($filter_role)."'";
    }
    $total_user = $conn->query("SELECT COUNT(*) as total FROM user $role_sql")->fetch_assoc()['total'];
    $users = $conn->query("SELECT * FROM user $role_sql ORDER BY role, nama LIMIT $limit OFFSET $offset_user");
    ?>

    <!-- Tabel Data User -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle bg-white">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Username</th> 
                    <th>Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1 + $offset_user;
                while($row = $users->fetch_assoc()): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= ucfirst(htmlspecialchars($row['role'])) ?></td>
                    <td>
                        <div class="action-buttons">
                            <a href="#" class="btn-edit" onclick="editUser(<?= $row['id'] ?>)">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php
    $total_pages_user = ceil($total_user / $limit);
    if ($total_pages_user > 1): ?>
    <nav>
      <ul class="pagination justify-content-center">
        <li class="page-item<?= $page_user == 1 ? ' disabled' : '' ?>">
          <a class="page-link" href="?menu=pengguna&page_user=<?= $page_user-1 ?>&filter_role=<?= urlencode($filter_role) ?>">Previous</a>
        </li>
        <?php for ($i = 1; $i <= $total_pages_user; $i++): ?>
          <li class="page-item<?= $page_user == $i ? ' active' : '' ?>">
            <a class="page-link" href="?menu=pengguna&page_user=<?= $i ?>&filter_role=<?= urlencode($filter_role) ?>"><?= $i ?></a>
          </li>
        <?php endfor; ?>
        <li class="page-item<?= $page_user == $total_pages_user ? ' disabled' : '' ?>">
          <a class="page-link" href="?menu=pengguna&page_user=<?= $page_user+1 ?>&filter_role=<?= urlencode($filter_role) ?>">Next</a>
        </li>
      </ul>
    </nav>
    <?php endif; ?>

    <!-- Modal Tambah/Edit User -->
    <div class="modal fade" id="formTambahUser" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="userForm" method="post" action="simpan_user.php">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah / Edit User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="user_id">
                        <div class="mb-3">
                            <label class="form-label">Nama</label>
                            <input type="text" name="nama" id="user_nama" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" id="user_username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" id="user_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select name="role" id="user_role" class="form-select" required>
                                <option value="">Pilih Role</option>
                                <option value="admin">Admin</option>
                                <option value="sekolah">Sekolah</option>
                                <option value="petugas">Petugas</option>
                                <option value="pengguna">Pengguna</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success" id="submitBtn" name="tambah_user">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
    </div>
</div>
<!-- Tambahkan Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function printTable(tableId) {
    var table = document.getElementById(tableId);
    var win = window.open('', '', 'width=1000,height=700');
    win.document.write('<html><head><title>Print</title>');
    win.document.write('<style>body{font-family:Arial,sans-serif;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #888;padding:8px;} th{background:#eafaf1;color:#256b25;} tr:nth-child(even){background:#f7faf7;}</style>');
    win.document.write('</head><body>');
    win.document.write(table.outerHTML);
    win.document.write('</body></html>');
    win.document.close();
    win.focus();
    win.print();
    win.close();
}

function toggleAlasanBelum() {
    var keterangan = document.getElementById('keterangan_mbg').value;
    var alasanWrap = document.getElementById('alasan_belum_wrap');
    alasanWrap.style.display = keterangan == 'Belum' ? 'block' : 'none';
}

<?php if($edit_sekolah): ?>
document.addEventListener('DOMContentLoaded', function() {
    var modal = new bootstrap.Modal(document.getElementById('formSekolah'));
    modal.show();
    toggleAlasanBelum();
});
<?php endif; ?>

<?php if($edit_pengaduan): ?>
document.addEventListener('DOMContentLoaded', function() {
    var modal = new bootstrap.Modal(document.getElementById('formPengaduan'));
    modal.show();
});
<?php endif; ?>

function bacaPesan(id) {
    fetch('baca_pesan.php?id=' + id)
        .then(response => response.json())
        .then(data => {
            if (data.status == 'success') {
                let pesan = data.data;
                let modal = new bootstrap.Modal(document.getElementById('modalBacaPesan'));
                document.getElementById('pesanPengirim').textContent = pesan.pengirim;
                document.getElementById('pesanSubjek').textContent = pesan.subjek;
                document.getElementById('pesanIsi').textContent = pesan.isi;
                document.getElementById('pesanTanggal').textContent = new Date(pesan.tanggal).toLocaleString();
                
                // Tampilkan balasan jika ada
                let balasanElem = document.getElementById('pesanBalasan');
                if (pesan.balasan) {
                    balasanElem.innerHTML = `
                        <div class="mt-2">
                            <strong>${pesan.balasan.pengirim}</strong> - 
                            <small>${new Date(pesan.balasan.tanggal).toLocaleString()}</small>
                            <p class="mt-1">${pesan.balasan.isi}</p>
                        </div>
                    `;
                } else {
                    balasanElem.innerHTML = '<em>Belum ada balasan</em>';
                }
                
                modal.show();
            }
        });
}

function balasPesan(id, pengirim, pengirimId) {
    fetch('baca_pesan.php?id=' + id)
        .then(response => response.json())
        .then(data => {
            if (data.status == 'success') {
                let pesan = data.data;
                let modal = new bootstrap.Modal(document.getElementById('modalBalasPesan'));
                document.getElementById('prevPengirim').textContent = pesan.pengirim;
                document.getElementById('prevSubjek').textContent = pesan.subjek;
                document.getElementById('prevTanggal').textContent = new Date(pesan.tanggal).toLocaleString();
                document.getElementById('prevIsi').textContent = pesan.isi;
                document.getElementById('balasKepada').value = pengirimId;
                document.getElementById('balasReplyTo').value = id;
                // Set subjek balasan sama persis dengan subjek pesan asli (tanpa "Re: ")
                document.getElementById('balasSubjek').value = pesan.subjek;
                modal.show();
            }
        });
}

function editUser(id) {
    fetch('get_user.php?id=' + id)
        .then(response => response.json())
        .then(data => {
            document.getElementById('user_id').value = data.id;
            document.getElementById('user_nama').value = data.nama;
            document.getElementById('user_username').value = data.username;
            document.getElementById('user_role').value = data.role;
            document.getElementById('user_password').required = false;
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.name = 'edit_user';
            submitBtn.textContent = 'Update';
            const modal = new bootstrap.Modal(document.getElementById('formTambahUser'));
           
            modal.show();
        });
}

document.getElementById('formTambahUser').addEventListener('hidden.bs.modal', function () {
    document.getElementById('userForm').reset();
    document.getElementById('user_id').value = '';
    document.getElementById('user_password').required = true;
    document.getElementById('submitBtn').name = 'tambah_user';
    document.getElementById('submitBtn').textContent = 'Simpan';
});
</script>

<!-- Modal Baca Pesan -->
<div class="modal fade" id="modalBacaPesan" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Pesan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <dl>
                    <dt><i class="fas fa-user"></i> Dari</dt>
                    <dd id="pesanPengirim"></dd>
                    <dt><i class="fas fa-envelope"></i> Subjek</dt>
                    <dd id="pesanSubjek"></dd>
                    <dt><i class="fas fa-calendar"></i> Tanggal</dt>
                    <dd id="pesanTanggal"></dd>
                    <dt><i class="fas fa-comment"></i> Pesan Sekolah</dt>
                    <dd id="pesanIsi"></dd>
                    <dt class="mt-4"><i class="fas fa-reply"></i> Balasan Admin</dt>
                    <dd id="pesanBalasan"><em>Belum ada balasan</em></dd>
                </dl>
            </div>
        </div>
    </div>
</div>

<!-- Modal Balas Pesan -->
<div class="modal fade" id="modalBalasPesan" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="kirim_pesan.php">
                <div class="modal-header">
                    <h5 class="modal-title">Balas Pesan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <dl>
                        <dt><i class="fas fa-user"></i> Dari</dt>
                        <dd id="prevPengirim"></dd>
                        <dt><i class="fas fa-envelope"></i> Subjek</dt>
                        <dd id="prevSubjek"></dd>
                        <dt><i class="fas fa-calendar"></i> Tanggal</dt>
                        <dd id="prevTanggal"></dd>
                        <dt><i class="fas fa-comment"></i> Pesan</dt>
                        <dd id="prevIsi"></dd>
                    </dl>
                    <input type="hidden" name="penerima_id" id="balasKepada">
                    <input type="hidden" name="reply_to" id="balasReplyTo">
                    <div class="mb-3">
                        <label class="form-label">Subjek</label>
                        <input type="text" name="subjek" class="form-control" id="balasSubjek" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Isi Pesan</label>
                        <textarea name="isi" class="form-control" rows="4" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Kirim Balasan</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
