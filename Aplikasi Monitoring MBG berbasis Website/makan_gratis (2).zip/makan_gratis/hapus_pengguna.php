<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Prevent admin from deleting their own account
    if ($id != $_SESSION['user_id']) {
        $stmt = $conn->prepare("DELETE FROM user WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Pengguna berhasil dihapus!";
        } else {
            $_SESSION['error'] = "Gagal menghapus pengguna!";
        }
        $stmt->close();
    } else {
        $_SESSION['error'] = "Tidak dapat menghapus akun sendiri!";
    }
}

header("Location: dashboard_admin.php?menu=pengguna");
exit;
