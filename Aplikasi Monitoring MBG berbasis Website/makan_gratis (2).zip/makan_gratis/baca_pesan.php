<?php
session_start();
include 'db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Update status menjadi sudah dibaca
    $stmt = $conn->prepare("UPDATE pesan SET status='Sudah Dibaca' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    // Ambil detail pesan beserta balasannya
    $query = "
        SELECT 
            p.*,
            u1.nama as pengirim,
            (SELECT JSON_OBJECT(
                'id', p2.id,
                'pengirim', u2.nama,
                'isi', p2.isi,
                'tanggal', p2.tanggal,
                'subjek', p2.subjek
            )
            FROM pesan p2 
            JOIN user u2 ON p2.pengirim_id = u2.id
            WHERE p2.reply_to = p.id
            ORDER BY p2.tanggal DESC
            LIMIT 1) as balasan
        FROM pesan p
        JOIN user u1 ON p.pengirim_id = u1.id
        WHERE p.id=?
    ";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($pesan = $result->fetch_assoc()) {
        $response = [
            'status' => 'success',
            'data' => [
                'id' => $pesan['id'],
                'pengirim' => $pesan['pengirim'],
                'subjek' => $pesan['subjek'],
                'isi' => $pesan['isi'],
                'tanggal' => $pesan['tanggal'],
                'balasan' => $pesan['balasan'] ? json_decode($pesan['balasan']) : null
            ]
        ];
    } else {
        $response = [
            'status' => 'error',
            'message' => 'Pesan tidak ditemukan'
        ];
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
}
