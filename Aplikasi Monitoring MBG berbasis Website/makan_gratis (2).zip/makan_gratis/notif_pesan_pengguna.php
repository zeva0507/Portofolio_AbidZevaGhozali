<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pengguna') {
    echo json_encode(['unread'=>0]); exit;
}
$pengguna_id = $_SESSION['user_id'];
// Hitung pesan dari petugas yang belum dibaca (status = 'Belum Dibaca')
$res = $conn->query("SELECT COUNT(*) as unread FROM pesan WHERE penerima_id = $pengguna_id AND status = 'Belum Dibaca'");
$row = $res->fetch_assoc();
echo json_encode(['unread'=>(int)$row['unread']]);
