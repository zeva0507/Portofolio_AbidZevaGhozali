<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pengguna') {
    header('Location: index.php');
    exit;
}
$pengguna_id = $_SESSION['user_id'];

// Menu aktif
$menu = isset($_GET['menu']) ? $_GET['menu'] : 'pengaduan';

// Proses tambah pengaduan
if ($menu == 'pengaduan' && isset($_POST['save_pengaduan'])) {
    $user_id = $pengguna_id;
    $isi = $_POST['isi'];
    $status = 'Belum Diproses';
    $foto = null;
    // Proses upload foto jika ada
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nama_file = 'pengaduan_' . time() . '_' . rand(1000,9999) . '.' . $ext;
        $target_file = $target_dir . $nama_file;
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
            $foto = $nama_file;
        }
    }
    $stmt = $conn->prepare("INSERT INTO pengaduan (user_id, isi, status, foto) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $isi, $status, $foto);
    $stmt->execute();
    header("Location: dashboard_pengguna.php?menu=pengaduan");
    exit;
}

// --- PAGINATION SETUP ---
$page_pengaduan = isset($_GET['page_pengaduan']) ? max(1, intval($_GET['page_pengaduan'])) : 1;
$limit = 5;
$offset_pengaduan = ($page_pengaduan - 1) * $limit;

// Filter & search for pengaduan
$status_pengaduan_filter = isset($_GET['filter_status_pengaduan']) ? $_GET['filter_status_pengaduan'] : '';
$status_pengaduan_sql = '';
if ($status_pengaduan_filter && $status_pengaduan_filter != 'all') {
    $status_pengaduan_sql = " AND pengaduan.status = '".$conn->real_escape_string($status_pengaduan_filter)."' ";
}
$search_pengaduan_sql = '';
if (!empty($_GET['search_pengaduan'])) {
    $search_pengaduan = $conn->real_escape_string($_GET['search_pengaduan']);
    $search_pengaduan_sql = " AND (user.nama LIKE '%$search_pengaduan%' OR pengaduan.isi LIKE '%$search_pengaduan%')";
}

// Data pengaduan untuk tabel Pengaduan
$total_pengaduan = $conn->query("SELECT COUNT(*) as total FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql")->fetch_assoc()['total'];
$pengaduan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql ORDER BY tanggal DESC LIMIT $limit OFFSET $offset_pengaduan");

// --- PAGINATION DATA SEKOLAH ---
$page_sekolah = isset($_GET['page_sekolah']) ? max(1, intval($_GET['page_sekolah'])) : 1;
$limit_sekolah = 5;
$offset_sekolah = ($page_sekolah - 1) * $limit_sekolah;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Pengguna</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --arya-green: #00512C;
            --arya-dark: #004024;
            --arya-light: #F5F5F5;
            --arya-gray: #707070;
            --arya-border: #E5E5E5;
        }

        body {
            background: var(--arya-light);
            font-family: 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            line-height: 1.6;
            color: #333;
        }

        table, .table, .table th, .table td {
            font-family: 'Poppins', sans-serif !important;
            font-size: 14px !important;
        }
        .table th, th {
            font-weight: 600 !important;
            color: #2c3e50;
        }
        .table td, td {
            font-weight: 400 !important;
            color: #333;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 220px;
            background: var(--arya-green);
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }

        .sidebar .logo-section {
            text-align: center;
            padding-bottom: 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar .logo-section img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            padding: 8px;
            background: rgba(255,255,255,0.1);
            margin-bottom: 12px;
            border: 2px solid rgba(255,255,255,0.1);
        }

        .sidebar .logo-section .title {
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sidebar .menu-section a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            font-size: 14px;
            border-radius: 6px;
            margin-bottom: 8px;
            transition: all 0.3s ease;
        }

        .sidebar .menu-section a:hover,
        .sidebar .menu-section a.active {
            background: rgba(255,255,255,0.1);
            color: #fff;
        }

        .sidebar .menu-section .logout-btn {
            margin-top: 20px;
            background: rgba(255,255,255,0.1);
            text-align: center;
        }

        .main-content {
            flex: 1;
            margin-left: 220px;
            padding: 25px;
            background: var(--arya-light);
        }

        .section-title {
            font-size: 22px;
            font-weight: 500;
            color: var(--arya-green);
            margin: 25px 0 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Update table styles */
        .table {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid var(--arya-border);
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .table thead th {
            background: var(--arya-green);
            color: #fff;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
            padding: 15px;
            border: none;
            vertical-align: middle;
        }

        .table tbody td {
            padding: 15px;
            border-bottom: 1px solid var(--arya-border);
            color: var(--arya-dark);
            font-size: 14px;
            background: #fff;
            vertical-align: middle;
            transition: background 0.3s;
        }

        .table tbody tr:hover td {
            background: #f8f9f8;
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .table-striped > tbody > tr:nth-of-type(odd) td {
            background: #fcfcfc;
        }

        .table-striped > tbody > tr:hover td {
            background: #f8f9f8;
        }

        .form-admin {
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            border: 1px solid var(--arya-border);
        }

        .form-admin input,
        .form-admin select,
        .form-admin textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid var(--arya-border);
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-admin input:focus,
        .form-admin select:focus,
        .form-admin textarea:focus {
            border-color: var(--arya-green);
            outline: none;
        }

        .form-admin label {
            display: block;
            margin-bottom: 8px;
            color: var(--arya-green);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-login {
            background: var(--arya-green);
            color: #fff;
            border: none;
            padding: 10px 25px;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            background: #006d3b;
        }

        .banner-makan-gratis {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid var(--arya-border);
            border-left: 6px solid var(--arya-green);
            margin-bottom: 25px;
        }

        .banner-title {
            color: var(--arya-green);
            font-size: 18px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }

        .banner-desc {
            color: var(--arya-green);
            font-size: 14px;
            line-height: 1.6;
        }

        .card-header {
            background: var(--arya-green) !important;
            color: #fff !important;
            border: none;
        }

        .btn-success {
            background: var(--arya-green) !important;
            border-color: var(--arya-green) !important;
        }

        .chat-container {
            border: 1px solid var(--arya-border);
        }

        .users-list {
            border-right: 1px solid var(--arya-border);
        }

        .user-chat {
            padding: 15px;
            border-bottom: 1px solid var(--arya-border);
            cursor: pointer;
        }

        .user-chat:hover {
            background: #e8f5e9;
        }

        .user-chat.active {
            background: #e8f5e9;
            border-left: 4px solid var(--arya-green);
        }

        .chat-input {
            padding: 15px;
            background: #f8f9fa;
            border-top: 1px solid var(--arya-border);
        }

        .chat-input form {
            display: flex;
            gap: 10px;
        }

        .chat-input input {
            flex: 1;
            padding: 10px 15px;
            border: 1px solid var(--arya-border);
            border-radius: 20px;
            outline: none;
        }

        .chat-input button {
            background: var(--arya-green);
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }

        .chat-input button:hover {
            background: var(--arya-dark);
        }

        /* Update message bubbles */
        .message-sent .message-bubble {
            background: var(--arya-green);
            color: #fff;
        }

        .message-received .message-bubble {
            background: #e8f5e9;
            color: var(--arya-dark);
        }

        /* Alert styles */
        .alert-success {
            background: #e8f5e9;
            color: var(--arya-green);
            border-color: var(--arya-green);
        }

        /* Form controls */
        .form-select:focus,
        .form-control:focus {
            border-color: var(--arya-green);
            box-shadow: 0 0 0 0.25rem rgba(0, 81, 44, 0.25);
        }

        .konsultasi-card {
            height: 500px;
        }
        
        .konsultasi-list {
            height: calc(100% - 56px);
            overflow-y: auto;
        }
        
        .petugas-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .petugas-item:hover {
            background: rgba(0, 81, 44, 0.05);
        }
        
        .petugas-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .staff-icon {
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
            border-radius: 10px;
            color: var(--arya-green);
        }
        
        .staff-name {
            font-weight: 600;
            font-size: 15px;
            color: #333;
        }
        
        .staff-role {
            font-size: 13px;
            color: #666;
        }
        
        .message-area {
            height: 400px;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }
        
        .message {
            margin-bottom: 20px;
            max-width: 80%;
        }
        
        .message-sent {
            margin-left: auto;
        }
        
        .message-content {
            padding: 12px 16px;
            border-radius: 8px;
            display: inline-block;
        }
        
        .message-sent .message-content {
            background: var(--arya-green);
            color: white;
        }
        
        .message-received .message-content {
            background: white;
            border: 1px solid #e5e5e5;
            color: #333;
        }
        
        .message-time {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        
        .empty-state {
            color: #aaa;
            text-align: center;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 10px;
            display: block;
        }

        .message-form {
            padding: 15px;
        }

        .bg-navy {
            background: #1a237e !important;
            color: white !important;
        }

        .portal-card {
            height: 500px;
            border-radius: 12px;
        }

        .portal-list {
            height: calc(100% - 56px);
            overflow-y: auto;
        }

        .portal-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: all 0.2s;
        }

        .portal-item:hover {
            background: rgba(26, 35, 126, 0.05);
        }

        .portal-avatar {
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #e8eaf6;
            border-radius: 8px;
            margin-right: 15px;
            color: #1a237e;
        }

        .staff-name {
            font-weight: 600;
            color: #333;
        }

        .staff-role {
            font-size: 13px;
            color: #666;
        }

        .portal-messages {
            height: 400px;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }

        .message {
            margin-bottom: 20px;
            max-width: 75%;
        }

        .message-sent {
            margin-left: auto;
        }

        .message-content {
            padding: 12px 16px;
            border-radius: 8px;
        }

        .message-sent .message-content {
            background: #1a237e;
            color: white;
        }

        .message-received .message-content {
            background: #e8eaf6;
            color: #1a237e;
        }

        .portal-form {
            bakground : #0d1757;
            padding: 15px;
        }

        .btn-navy {
            background: #1a237e;
            color: white;
            border: none;
        }

        .btn-navy:hover {
            background: #0d1757;
            color: white;
        }

        .empty-state {
            color: #9fa8da;
            text-align: center;
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="sidebar">
        <div class="logo-section">
            <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Logo Pengguna">
            <div class="title">
                Dashboard Pengguna<br>
                <span class="name"><?= htmlspecialchars($_SESSION['nama']) ?></span>
            </div>
        </div>
        <div class="menu-section">
            <a href="?menu=pengaduan" class="<?= $menu=='pengaduan'?'active':'' ?>">Pengaduan</a>
            <a href="?menu=sekolah" class="<?= $menu=='sekolah'?'active':'' ?>">Data Sekolah</a>
            <a href="?menu=komunikasi" class="<?= $menu=='komunikasi'?'active':'' ?>">Portal Komunikasi</a>
            <a href="?menu=cetak_laporan" class="<?= $menu=='cetak_laporan'?'active':'' ?>">Cetak Laporan</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="main-content">
        <div class="container py-4">
            <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white">
                <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png"alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:#fff;border-radius:50%;padding:10px;border:6px solid var(--arya-green);">
                <div class="banner-text">
                    <div class="banner-title fw-bold" style="color:var(--arya-green);">
                        Program Makan Siang Gratis Prabowo
                    </div>
                    <div class="banner-desc" style="color:var(--arya-green);">
                        Dapatkan makan siang bergizi gratis untuk siswa sekolah! Pantau distribusi, menu, dan pengaduan di dashboard ini.
                    </div>
                </div>
            </div>
            <?php if ($menu=='pengaduan'): ?>
                <!-- Title and Add Button -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="section-title mb-0">Data Pengaduan</h3>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formPengaduan">
                        <i class="fas fa-plus"></i> Tambah Pengaduan
                    </button>
                </div>

                <!-- Filter Form: Select Status + Search -->
                <form method="get" class="row g-2 mb-3 align-items-center">
                    <input type="hidden" name="menu" value="pengaduan">
                    <div class="col-md-3">
                        <select name="filter_status_pengaduan" class="form-select" onchange="this.form.submit()">
                            <option value="all" <?= $status_pengaduan_filter=='all'||$status_pengaduan_filter==''?'selected':'' ?>>Semua Status</option>
                            <option value="Belum Diproses" <?= $status_pengaduan_filter=='Belum Diproses'?'selected':'' ?>>Belum Diproses</option>
                            <option value="Diproses" <?= $status_pengaduan_filter=='Diproses'?'selected':'' ?>>Diproses</option>
                            <option value="Selesai" <?= $status_pengaduan_filter=='Selesai'?'selected':'' ?>>Selesai</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="text" name="search_pengaduan" class="form-control" placeholder="Cari nama pelapor/isi pengaduan..." value="<?= isset($_GET['search_pengaduan']) ? htmlspecialchars($_GET['search_pengaduan']) : '' ?>">
                    </div>
                    <div class="col-md-2 d-grid">
                        <button type="submit" class="btn btn-success">Filter</button>
                    </div>
                </form>

                <!-- Modal Form -->
                <div class="modal fade" id="formPengaduan" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Tambah Pengaduan</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <!-- Tambahkan enctype untuk upload file -->
                                <form method="post" class="form-admin" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label class="form-label">Isi Pengaduan</label>
                                        <textarea name="isi" class="form-control" required rows="4"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Foto (opsional)</label>
                                        <input type="file" name="foto" class="form-control" accept="image/*">
                                    </div>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" name="save_pengaduan" class="btn btn-success">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Table section -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle bg-white">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Pelapor</th>
                                <th>Isi Pengaduan</th>
                                <th>Bukti Foto</th>
                                <th>Komentar</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1 + $offset_pengaduan; while($row = $pengaduan->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['pelapor']) ?></td>
                                <td><?= htmlspecialchars($row['isi']) ?></td>
                                <td>
                                    <?php if (!empty($row['foto'])): ?>
                                        <a href="uploads/<?= htmlspecialchars($row['foto']) ?>" target="_blank">
                                            <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="foto" style="max-width:70px;max-height:70px;border-radius:6px;">
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= !empty($row['komentar']) ? nl2br(htmlspecialchars($row['komentar'])) : '<span class="text-muted">-</span>' ?>
                                </td>
                                <td><?= htmlspecialchars($row['tanggal']) ?></td>
                                <td><?= htmlspecialchars($row['status']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php
                $total_pages_pengaduan = ceil($total_pengaduan / $limit);
                if ($total_pages_pengaduan > 1): ?>
                <nav>
                  <ul class="pagination justify-content-center">
                    <li class="page-item<?= $page_pengaduan == 1 ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan-1 ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search_pengaduan=<?= urlencode(isset($_GET['search_pengaduan']) ? $_GET['search_pengaduan'] : '') ?>">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages_pengaduan; $i++): ?>
                      <li class="page-item<?= $page_pengaduan == $i ? ' active' : '' ?>">
                        <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $i ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search_pengaduan=<?= urlencode(isset($_GET['search_pengaduan']) ? $_GET['search_pengaduan'] : '') ?>"><?= $i ?></a>
                      </li>
                    <?php endfor; ?>
                    <li class="page-item<?= $page_pengaduan == $total_pages_pengaduan ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan+1 ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search_pengaduan=<?= urlencode(isset($_GET['search_pengaduan']) ? $_GET['search_pengaduan'] : '') ?>">Next</a>
                    </li>
                  </ul>
                </nav>
                <?php endif; ?>
            <?php elseif ($menu=='sekolah'): ?>
                <h3 class="section-title">Daftar Data Sekolah</h3>
                <!-- Filter & Search -->
                <form method="get" style="margin-bottom:16px;display:flex;gap:10px;flex-wrap:wrap;">
                    <input type="hidden" name="menu" value="sekolah">
                    <select name="filter_jenjang">
                        <option value="">Semua Jenjang</option>
                        <option value="SD" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SD'?'selected':'' ?>>SD</option>
                        <option value="SMP" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMP'?'selected':'' ?>>SMP</option>
                        <option value="SMA" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMA'?'selected':'' ?>>SMA</option>
                        <option value="SMK" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMK'?'selected':'' ?>>SMK</option>
                    </select>
                    <select name="filter_status">
                        <option value="">Semua Status</option>
                        <option value="Negeri" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Negeri'?'selected':'' ?>>Negeri</option>
                        <option value="Swasta" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Swasta'?'selected':'' ?>>Swasta</option>
                    </select>
                    <input type="text" name="search" placeholder="Cari nama/alamat..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>" style="min-width:180px;">
                    <button type="submit" class="btn-login" style="width:auto;padding:6px 18px;">Filter</button>
                    <?php if (isset($_GET['filter_jenjang']) || isset($_GET['filter_status']) || isset($_GET['search'])): ?>
                        <a href="dashboard_pengguna.php?menu=sekolah" style="margin-left:8px;">Reset</a>
                    <?php endif; ?>
                </form>
                <?php
                // Filter query
                $where = [];
                if (!empty($_GET['filter_jenjang'])) {
                    $jenjang = $conn->real_escape_string($_GET['filter_jenjang']);
                    $where[] = "jenjang='$jenjang'";
                }
                if (!empty($_GET['filter_status'])) {
                    $status = $conn->real_escape_string($_GET['filter_status']);
                    $where[] = "status_sekolah='$status'";
                }
                if (!empty($_GET['search'])) {
                    $search = $conn->real_escape_string($_GET['search']);
                    $where[] = "(nama LIKE '%$search%' OR alamat LIKE '%$search%')";
                }
                $whereSql = $where ? " AND " . implode(" AND ", $where) : "";
                $total_sekolah = $conn->query("SELECT COUNT(*) as total FROM user WHERE role='sekolah' $whereSql")->fetch_assoc()['total'];
                $user = $conn->query("SELECT * FROM user WHERE role='sekolah' $whereSql ORDER BY nama LIMIT $limit_sekolah OFFSET $offset_sekolah");
                ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle bg-white">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Sekolah</th>
                                <th>Alamat</th>
                                <th>Jenjang</th>
                                <th>Status Sekolah</th>
                                <th>Keterangan MBG</th>
                                <th>Alasan Belum MBG</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1 + $offset_sekolah; while($row = $user->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                <td><?= htmlspecialchars($row['alamat']) ?></td>
                                <td><?= isset($row['jenjang']) ? htmlspecialchars($row['jenjang']) : '-' ?></td>
                                <td><?= isset($row['status_sekolah']) ? htmlspecialchars($row['status_sekolah']) : '-' ?></td>
                                <td><?= isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                                <td><?= ($row['keterangan']=='Belum') ? htmlspecialchars($row['alasan_belum']) : '-' ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php
                $total_pages_sekolah = ceil($total_sekolah / $limit_sekolah);
                if ($total_pages_sekolah > 1): ?>
                <nav>
                  <ul class="pagination justify-content-center mt-3">
                    <li class="page-item<?= $page_sekolah == 1 ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah-1 ?>">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages_sekolah; $i++): ?>
                      <li class="page-item<?= $page_sekolah == $i ? ' active' : '' ?>">
                        <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $i ?>"><?= $i ?></a>
                      </li>
                    <?php endfor; ?>
                    <li class="page-item<?= $page_sekolah == $total_pages_sekolah ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah+1 ?>">Next</a>
                    </li>
                  </ul>
                </nav>
                <?php endif; ?>
            <?php elseif ($menu=='cetak_laporan'): ?>
                <h3 class="section-title">Cetak Laporan</h3>
                <form method="get" class="mb-4">
                    <input type="hidden" name="menu" value="cetak_laporan">
                    <select name="laporan" required class="form-select" style="max-width:300px;display:inline-block;">
                        <option value="">Pilih Data Laporan</option>
                        <option value="sekolah" <?= (isset($_GET['laporan']) && $_GET['laporan']=='sekolah')?'selected':'' ?>>Data Sekolah</option>
                        <option value="pengaduan" <?= (isset($_GET['laporan']) && $_GET['laporan']=='pengaduan')?'selected':'' ?>>Pengaduan</option>
                    </select>
                    <button type="submit" class="btn btn-success ms-2" style="background:var(--arya-green);border:none;">
                        <i class="fas fa-search me-2"></i>Tampilkan
                    </button>
                </form>

                <?php if (isset($_GET['laporan']) && $_GET['laporan']=='sekolah'): ?>
                    <div class="card border-0 shadow-sm">
                        <div class="card-header py-3" style="background:var(--arya-green);">
                            <h5 class="mb-0 text-white">
                                <i class="fas fa-school me-2"></i>
                                Laporan Data Sekolah
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php $laporan = $conn->query("SELECT * FROM user WHERE role='sekolah' ORDER BY nama"); ?>
                            <div class="table-responsive">
                                <table id="table-laporan" class="table table-bordered table-hover align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th style="background:var(--arya-green);color:#fff;">No</th>
                                            <th style="background:var(--arya-green);color:#fff;">Nama Sekolah</th>
                                            <th style="background:var(--arya-green);color:#fff;">Alamat</th>
                                            <th style="background:var(--arya-green);color:#fff;">Jenjang</th>
                                            <th style="background:var(--arya-green);color:#fff;">Status Sekolah</th>
                                            <th style="background:var(--arya-green);color:#fff;">Keterangan MBG</th>
                                            <th style="background:var(--arya-green);color:#fff;">Alasan Belum MBG</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no=1; while($row = $laporan->fetch_assoc()): ?>
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                                <td><?= htmlspecialchars($row['alamat']) ?></td>
                                                <td><?= isset($row['jenjang']) ? htmlspecialchars($row['jenjang']) : '-' ?></td>
                                                <td><?= isset($row['status_sekolah']) ? htmlspecialchars($row['status_sekolah']) : '-' ?></td>
                                                <td><?= isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                                                <td><?= ($row['keterangan']=='Belum') ? htmlspecialchars($row['alasan_belum']) : '-' ?></td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer bg-white py-3">
                            <button onclick="printTable('table-laporan')" class="btn btn-success">
                                <i class="fas fa-print me-2"></i>Cetak Laporan
                            </button>
                        </div>
                    </div>

                <?php elseif (isset($_GET['laporan']) && $_GET['laporan']=='pengaduan'): ?>
                    <div class="card border-0 shadow-sm">
                        <div class="card-header py-3" style="background:var(--arya-green);">
                            <h5 class="mb-0 text-white">
                                <i class="fas fa-file-alt me-2"></i>
                                Laporan Pengaduan
                            </h5>
                        </div>
                        <div class="card-body">
                            <style>
                            #table-laporan {
                                border: 1.5px solid #1d5c39;
                                border-radius: 8px;
                                overflow: hidden;
                                box-shadow: 0 2px 8px rgba(29,92,57,0.08);
                            }
                            #table-laporan th {
                                background: #1d5c39 !important;
                                color: #fff !important;
                                font-weight: 600;
                                text-transform: uppercase;
                                font-size: 14px;
                                letter-spacing: 0.5px;
                                padding: 14px 10px;
                                border: 1px solid #e0e0e0;
                            }
                            #table-laporan td {
                                background: #fff;
                                color: #222;
                                padding: 12px 10px;
                                border: 1px solid #e0e0e0;
                                vertical-align: middle;
                            }
                            #table-laporan tr:nth-child(even) td {
                                background: #f7faf7;
                            }
                            #table-laporan img {
                                border-radius: 6px;
                                border: 1px solid #e0e0e0;
                                background: #f7faf7;
                            }
                            </style>
                            <?php $laporan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id ORDER BY tanggal DESC"); ?>
                            <div class="table-responsive">
                                <table id="table-laporan" class="align-middle mb-0" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th>Pelapor</th>
                                            <th>Isi Pengaduan</th>
                                            <th>Bukti Foto</th>
                                            <th>Komentar</th>
                                            <th>Tanggal</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($row = $laporan->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['pelapor']) ?></td>
                                            <td><?= htmlspecialchars($row['isi']) ?></td>
                                            <td>
                                                <?php if (!empty($row['foto'])): ?>
                                                    <a href="uploads/<?= htmlspecialchars($row['foto']) ?>" target="_blank">
                                                        <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="foto" style="max-width:70px;max-height:70px;">
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?= !empty($row['komentar']) ? nl2br(htmlspecialchars($row['komentar'])) : '<span class="text-muted">-</span>' ?>
                                            </td>
                                            <td><?= htmlspecialchars($row['tanggal']) ?></td>
                                            <td><?= htmlspecialchars($row['status']) ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer bg-white py-3">
                            <button onclick="printTable('table-laporan')" class="btn btn-success">
                                <i class="fas fa-print me-2"></i>Cetak Laporan
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
            <?php elseif ($menu=='komunikasi'): ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card portal-card border-0 shadow-sm">
                            <div class="card-header bg-navy">
                                <h5 class="card-title text-white mb-0">
                                    <i class="fas fa-headset me-2"></i>Daftar Petugas 
                                </h5>
                            </div>
                            <div class="portal-list">
                                <?php
                                $petugas = $conn->query("SELECT * FROM user WHERE role='petugas' ORDER BY nama");
                                while($p = $petugas->fetch_assoc()): ?>
                                    <div class="portal-item" onclick="loadChat(<?= $p['id'] ?>)">
                                        <div class="portal-avatar">
                                            <i class="fas fa-user-tie"></i>
                                        </div>
                                        <div class="staff-info">
                                            <div class="staff-name"><?= htmlspecialchars($p['nama']) ?></div>
                                            <div class="staff-role">Petugas</div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="card portal-card border-0 shadow-sm">
                            <div class="card-header bg-navy">
                                <h5 class="card-title text-white mb-0">
                                    <i class="fas fa-comments me-2"></i>Konsultasi
                                </h5>
                            </div>
                            <div class="portal-messages" id="chatBox">
                                <div class="text-center p-5">
                                    <div class="empty-state">
                                        <i class="fas fa-comments-alt mb-3"></i>
                                        <p>Pilih admin untuk memulai konsultasi</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-white">
                                <form id="chatForm" class="portal-form">
                                    <input type="hidden" id="receiver_id" name="receiver_id">
                                    <div class="input-group">
                                        <input type="text" id="messageInput" class="form-control" 
                                               placeholder="Ketik pesan..." autocomplete="off">
                                        <button type="submit" class="btn btn-navy">
                                            <i class="fas fa-paper-plane"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <style>
                .bg-navy {
                    background: #1a237e !important;
                    color: white !important;
                }

                .portal-card {
                    height: 500px;
                    border-radius: 12px;
                }

                .portal-list {
                    height: calc(100% - 56px);
                    overflow-y: auto;
                }

                .portal-item {
                    display: flex;
                    align-items: center;
                    padding: 15px;
                    border-bottom: 1px solid #eee;
                    cursor: pointer;
                    transition: all 0.2s;
                }

                .portal-item:hover {
                    background: rgba(26, 35, 126, 0.05);
                }

                .portal-avatar {
                    width: 45px;
                    height: 45px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: #e8eaf6;
                    border-radius: 8px;
                    margin-right: 15px;
                    color: #1a237e;
                }

                .staff-name {
                    font-weight: 600;
                    color: #333;
                }

                .staff-role {
                    font-size: 13px;
                    color: #666;
                }

                .portal-messages {
                    height: 400px;
                    overflow-y: auto;
                    padding: 20px;
                    background: #f8f9fa;
                }

                .message {
                    margin-bottom: 20px;
                    max-width: 75%;
                }

                .message-sent {
                    margin-left: auto;
                }

                .message-content {
                    padding: 12px 16px;
                    border-radius: 8px;
                }

                .message-sent .message-content {
                    background: #1a237e;
                    color: white;
                }

                .message-received .message-content {
                    background: #e8eaf6;
                    color: #1a237e;
                }

                .portal-form {
                    padding: 15px;
                }

                .btn-navy {
                    background: #1a237e;
                    color: white;
                    border: none;
                }

                .btn-navy:hover {
                    background: #0d1757;
                    color: white;
                }

                .empty-state {
                    color: #9fa8da;
                    text-align: center;
                }

                .empty-state i {
                    font-size: 48px;
                    margin-bottom: 15px;
                }
                </style>

                <script>
                function loadChat(userId) {
                    document.getElementById('receiver_id').value = userId;
                    fetch('load_chat.php?user_id=' + userId)
                        .then(response => response.text())
                        .then(html => {
                            document.getElementById('chatBox').innerHTML = html;
                            chatBox.scrollTop = chatBox.scrollHeight;
                        });
                }

                document.getElementById('chatForm').onsubmit = function(e) {
                    e.preventDefault();
                    let message = document.getElementById('messageInput').value;
                    let receiver = document.getElementById('receiver_id').value;
                    
                    if(!message || !receiver) return;

                    fetch('send_message.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'message=' + encodeURIComponent(message) + '&receiver_id=' + receiver
                    })
                    .then(() => {
                        document.getElementById('messageInput').value = '';
                        loadChat(receiver);
                    });
                }
                </script>
            <?php endif; ?>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function printTable(tableId) {
    var table = document.getElementById(tableId);
    var win = window.open('', '', 'width=1000,height=700');
    win.document.write('<html><head><title>Print</title>');
    win.document.write('<style>body{font-family:Arial,sans-serif;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #888;padding:8px;} th{background:#eafaf1;color:#256b25;} tr:nth-child(even){background:#f7faf7;}</style>');
    win.document.write('</head><body>');
    win.document.write(table.outerHTML);
    win.document.write('</body></html>');
    win.document.close();
    win.focus();
    win.print();
    win.close();
}
</script>
</body>
</html>
