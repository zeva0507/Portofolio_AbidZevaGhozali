<?php
include 'db.php';

// Check if column exists
$result = $conn->query("SHOW COLUMNS FROM distribusi_makanan LIKE 'catatan_sekolah'");
if ($result->num_rows == 0) {
    // Column doesn't exist, so add it
    $sql = "ALTER TABLE distribusi_makanan ADD COLUMN catatan_sekolah TEXT";
    if ($conn->query($sql)) {
        echo "Column catatan_sekolah added successfully";
    } else {
        echo "Error adding column: " . $conn->error;
    }
} else {
    echo "Column catatan_sekolah already exists";
}
?>
