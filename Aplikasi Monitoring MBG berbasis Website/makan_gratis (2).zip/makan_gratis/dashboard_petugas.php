<?php
session_start();
include 'db.php';

// Tambah user petugas jika diminta via GET
if (isset($_GET['tambah_petugas'])) {
    $nama = 'Nama Petugas';
    $username = 'username_petugas';
    $password = password_hash('password_petugas', PASSWORD_DEFAULT); // hash password
    $role = 'petugas';
    $alamat = 'Alamat Petugas';

    $stmt = $conn->prepare("INSERT INTO user (nama, username, password, role, alamat) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $nama, $username, $password, $role, $alamat);
    $stmt->execute();
    $stmt->close();

    echo "User petugas berhasil ditambahkan!";
    exit;
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'petugas') {
    header('Location: index.php');
    exit;
}

// Tambah menu pengaduan untuk petugas
$menu = isset($_GET['menu']) ? $_GET['menu'] : 'makanan';

// Tambahkan filter status_distribusi
$status_filter = isset($_GET['filter_status_distribusi']) ? $_GET['filter_status_distribusi'] : '';
$status_sql = '';
if ($menu == 'makanan' && $status_filter && $status_filter != 'all') {
    $status_sql = " AND d.status_distribusi = '".$conn->real_escape_string($status_filter)."' ";
}

// --- PAGINATION SETUP ---
$page_sekolah = isset($_GET['page_sekolah']) ? max(1, intval($_GET['page_sekolah'])) : 1;
$page_makanan = isset($_GET['page_makanan']) ? max(1, intval($_GET['page_makanan'])) : 1;
$limit = 5;
$offset_sekolah = ($page_sekolah - 1) * $limit;
$offset_makanan = ($page_makanan - 1) * $limit;

// Handle tambah/edit/hapus makanan
if (isset($_POST['save_makanan'])) {
    $jumlah = intval($_POST['jumlah']);
    $sekolah_id = intval($_POST['sekolah_id']);
    $tanggal_kirim = $_POST['tanggal_kirim'];
    $lauk_menu = $_POST['lauk_menu'];

    // Ambil alamat sekolah dari tabel user
    $alamat = '';
    $getAlamat = $conn->prepare("SELECT alamat FROM user WHERE id=?");
    $getAlamat->bind_param("i", $sekolah_id);
    $getAlamat->execute();
    $getAlamat->bind_result($alamat);
    $getAlamat->fetch();
    $getAlamat->close();

    if ($_POST['id'] == '') {
        // Tambah makanan
        $stmt = $conn->prepare("INSERT INTO makanan_kirim (jumlah, sekolah_id, tanggal_kirim, lauk_menu, alamat) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisss", $jumlah, $sekolah_id, $tanggal_kirim, $lauk_menu, $alamat);
        $stmt->execute();
        $makanan_id = $conn->insert_id;
        $stmt->close();

        // Buat jadwal distribusi otomatis
        $stmt = $conn->prepare("INSERT INTO distribusi_makanan (makanan_id, jadwal_kirim, status_distribusi) VALUES (?, ?, 'Dijadwalkan')");
        $stmt->bind_param("is", $makanan_id, $tanggal_kirim);
        $stmt->execute();
        $stmt->close();
    } else {
        // Edit existing record
        $stmt = $conn->prepare("UPDATE makanan_kirim SET jumlah=?, sekolah_id=?, tanggal_kirim=?, lauk_menu=?, alamat=? WHERE id=?");
        $stmt->bind_param("iisssi", $jumlah, $sekolah_id, $tanggal_kirim, $lauk_menu, $alamat, $_POST['id']);
        $stmt->execute();
        $stmt->close();

        // Update existing distribution if exists
        $stmt = $conn->prepare("UPDATE distribusi_makanan SET jadwal_kirim=? WHERE makanan_id=?");
        $stmt->bind_param("si", $tanggal_kirim, $_POST['id']);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: dashboard_petugas.php?menu=makanan");
    exit;
}
if (isset($_GET['hapus_makanan'])) {
    $id = intval($_GET['hapus_makanan']);
    $conn->query("DELETE FROM makanan_kirim WHERE id=$id");
    header("Location: dashboard_petugas.php");
    exit;
}
$edit_makanan = null;
if (isset($_GET['edit_makanan'])) {
    $id = intval($_GET['edit_makanan']);
    $res = $conn->query("SELECT * FROM makanan_kirim WHERE id=$id");
    $edit_makanan = $res->fetch_assoc();
}

// Data sekolah untuk dropdown
$user_sekolah = $conn->query("SELECT * FROM user WHERE role='sekolah' AND keterangan='Sudah' ORDER BY nama");
// Data makanan dengan pagination
$makanan = $conn->query("SELECT makanan_kirim.*, user.nama as sekolah_nama FROM makanan_kirim LEFT JOIN user ON makanan_kirim.sekolah_id=user.id ORDER BY tanggal_kirim DESC LIMIT $limit OFFSET $offset_makanan");
// Data sekolah untuk tabel Data Sekolah 
$where = ["role='sekolah'"]; // Base condition

if (!empty($_GET['filter_jenjang'])) {
    $jenjang = $conn->real_escape_string($_GET['filter_jenjang']);
    $where[] = "jenjang='$jenjang'";
}

if (!empty($_GET['filter_status'])) {
    $status = $conn->real_escape_string($_GET['filter_status']);
    $where[] = "status_sekolah='$status'";
}

if (!empty($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $where[] = "(nama LIKE '%$search%' OR alamat LIKE '%$search%')";
}

$whereSql = implode(" AND ", $where);
$data_sekolah = $conn->query("SELECT * FROM user WHERE $whereSql ORDER BY nama LIMIT $limit OFFSET $offset_sekolah");

// Handle tambah/edit sekolah (khusus petugas, tanpa username/password)
if (isset($_POST['save_sekolah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $jenjang = $_POST['jenjang'];
    $status_sekolah = $_POST['status_sekolah'];
    $keterangan = $_POST['keterangan'];
    $alasan_belum = isset($_POST['alasan_belum']) ? $_POST['alasan_belum'] : '';
    if ($_POST['id'] == '') {
        // Tambah
        $stmt = $conn->prepare("INSERT INTO user (nama, alamat, jenjang, status_sekolah, keterangan, alasan_belum, role, username, password) VALUES (?, ?, ?, ?, ?, ?, 'sekolah', ?, ?)");
        $username = uniqid('sekolah');
        $password = password_hash('12345', PASSWORD_DEFAULT);
        $stmt->bind_param("ssssssss", $nama, $alamat, $jenjang, $status_sekolah, $keterangan, $alasan_belum, $username, $password);
        $stmt->execute();
        $stmt->close();
    } else {
        // Edit
        $stmt = $conn->prepare("UPDATE user SET nama=?, alamat=?, jenjang=?, status_sekolah=?, keterangan=?, alasan_belum=? WHERE id=?");
        $stmt->bind_param("ssssssi", $nama, $alamat, $jenjang, $status_sekolah, $keterangan, $alasan_belum, $_POST['id']);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: dashboard_petugas.php?menu=sekolah&success=1");
    exit;
}
$edit_sekolah = null;
if (isset($_GET['edit_sekolah'])) {
    $id = intval($_GET['edit_sekolah']);
    $res = $conn->query("SELECT * FROM user WHERE id=$id AND role='sekolah'");
    $edit_sekolah = $res->fetch_assoc();
}
if (isset($_GET['hapus_sekolah'])) {
    $id = intval($_GET['hapus_sekolah']);
    $conn->query("DELETE FROM user WHERE id=$id AND role='sekolah'");
    header("Location: dashboard_petugas.php?menu=sekolah");
    exit;
}

// Proses tambah pengaduan (khusus petugas)
if ($menu == 'pengaduan' && isset($_POST['save_pengaduan'])) {
    $user_id = $_SESSION['user_id'];
    $isi = $_POST['isi'];
    $status = 'Belum Diproses';
    $foto = null;
    // Proses upload foto jika ada
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nama_file = 'pengaduan_' . time() . '_' . rand(1000,9999) . '.' . $ext;
        $target_file = $target_dir . $nama_file;
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
            $foto = $nama_file;
        }
    }
    $stmt = $conn->prepare("INSERT INTO pengaduan (user_id, isi, status, foto) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $isi, $status, $foto);
    $stmt->execute();
    header("Location: dashboard_petugas.php?menu=pengaduan");
    exit;
}

// Ambil data pengaduan untuk petugas
if ($menu == 'pengaduan') {
    // Tambahkan filter status pengaduan
    $status_pengaduan_filter = isset($_GET['filter_status_pengaduan']) ? $_GET['filter_status_pengaduan'] : '';
    $status_pengaduan_sql = '';
    if ($status_pengaduan_filter && $status_pengaduan_filter != 'all') {
        $status_pengaduan_sql = " AND pengaduan.status = '".$conn->real_escape_string($status_pengaduan_filter)."' ";
    }
    $limit_pengaduan = 5;
    $page_pengaduan = isset($_GET['page_pengaduan']) ? max(1, intval($_GET['page_pengaduan'])) : 1;
    $offset_pengaduan = ($page_pengaduan - 1) * $limit_pengaduan;
    $total_pengaduan = $conn->query("SELECT COUNT(*) as total FROM pengaduan WHERE 1=1 $status_pengaduan_sql")->fetch_assoc()['total'];
    $pengaduan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql ORDER BY tanggal DESC LIMIT $limit_pengaduan OFFSET $offset_pengaduan");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Petugas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="includes/action_buttons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
    :root {
        --arya-green: #00512C;
        --arya-dark: #004024;
        --arya-light: #F5F5F5;
        --arya-gray: #707070;
        --arya-border: #E5E5E5;
    }

    body {
        background: var(--arya-light);
        font-family: 'Helvetica Neue', Arial, sans-serif;
    }

    table, .table, .table th, .table td {
        font-family: 'Poppins', sans-serif !important;
        font-size: 14px !important;
    }
    .table th, th {
        font-weight: 600 !important;
        color: #2c3e50;
    }
    .table td, td {
        font-weight: 400 !important;
        color: #333;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }

    .sidebar {
        background: var(--arya-green);
        width: 280px;
        padding: 25px;
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
    }

    .sidebar .logo-section {
        padding-bottom: 25px;
        margin-bottom: 25px;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        text-align: center;
    }

    .sidebar .logo-section img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        padding: 10px;
        background: rgba(255,255,255,0.1);
        margin-bottom: 15px;
    }

    .sidebar .logo-section .title {
        color: #fff;
        font-size: 20px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        line-height: 1.4;
    }

    .sidebar .logo-section .name {
        font-size: 16px;
        font-weight: normal;
        opacity: 0.9;
    }

    .sidebar .menu-section {
        margin-top: 20px;
    }

    .sidebar .menu-section a {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        color: rgba(255,255,255,0.8);
        text-decoration: none;
        font-size: 15px;
        border-radius: 6px;
        transition: all 0.3s ease;
        margin-bottom: 5px;
    }

    .sidebar .menu-section a:hover,
    .sidebar .menu-section a.active {
        background: rgba(255,255,255,0.1);
        color: #fff;
    }

    .sidebar .menu-section .logout-btn {
        background: rgba(255,255,255,0.1);
        padding: 12px 20px;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        margin-top: 20px;
        transition: all 0.3s ease;
    }

    .sidebar .menu-section .logout-btn:hover {
        background: var(--arya-dark);
    }

    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 30px;
    }

    .top-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }

    .section-title {
        font-size: 24px;
        font-weight: 600;
        color: var(--arya-green);
        text-transform: uppercase;
        letter-spacing: 1px;
        margin: 0;
    }

    .form-admin {
        background: #fff;
        padding: 40px;
        border-radius: 8px;
        margin-bottom: 30px;
        max-width: 800px;
        margin-left: auto;
        margin-right: auto;
        border: 1px solid var(--arya-border);
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    .form-admin input,
    .form-admin select {
        width: 100%;
        padding: 12px 15px;
        margin-bottom: 20px;
        border: 1px solid var(--arya-border);
        border-radius: 6px;
        background: #fff;
        color: var(--arya-gray);
        font-size: 15px;
        transition: all 0.3s ease;
        height: 50px;
    }

    .form-admin input::placeholder,
    .form-admin select {
        color: var(--arya-gray);
    }

    .form-admin label {
        display: block;
        margin-bottom: 10px;
        color: var(--arya-green);
        font-size: 16px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .form-admin .button-container {
        text-align: center;
        margin-top: 30px;
    }

    .form-admin button {
        background: var(--arya-green);
        color: #fff;
        border: none;
        padding: 12px 40px;
        border-radius: 6px;
        font-size: 16px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-block;
    }

    .form-admin button:hover {
        background: var(--arya-dark);
        color: #fff;
    }

    .form-admin a {
        color: var(--arya-gray);
        text-decoration: none;
        opacity: 0.8;
        transition: opacity 0.3s ease;
    }

    .form-admin a:hover {
        opacity: 1;
    }

    .table {
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid var(--arya-border);
    }

    .table th {
        background: var(--arya-green);
        color: #fff;
        font-weight: 500;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        padding: 15px;
    }

    .table td {
        padding: 15px;
        color: var(--arya-gray);
        font-size: 14px;
        border-bottom: 1px solid var(--arya-border);
    }

    .action-btn {
        padding: 6px 16px;
        font-size: 13px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-radius: 4px;
        transition: all 0.3s ease;
    }

    .edit-btn {
        background: rgba(0, 81, 44, 0.1);
        color: var(--arya-green) !important;
    }

    .hapus-btn {
        background: rgba(220, 38, 38, 0.1);
        color: #DC2626 !important;
    }

    .banner-makan-gratis {
        background: #fff;
        padding: 25px;
        border-radius: 8px;
        border: 1px solid var(--arya-border);
        border-left: 6px solid var(--arya-green) !important;
        margin-bottom: 30px;
    }

    .user-chat {
        transition: all 0.3s ease;
        cursor: pointer;
    }
    .user-chat:hover {
        background: #f8f9fa;
    }
    .chat-avatar {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .message {
        max-width: 75%;
        margin-bottom: 1rem;
    }
    .message-sent {
        margin-left: auto;
    }
    .message-bubble {
        padding: 10px 15px;
        border-radius: 15px;
        background: var(--arya-green);
        color: #fff;
    }
    .message-received .message-bubble {
        background: #e9ecef;
        color: #212529;
    }
    .chat-box::-webkit-scrollbar {
        width: 5px;
    }
    .chat-box::-webkit-scrollbar-thumb {
        background: #ddd;
        border-radius: 5px;
    }

    .bg-custom {
        background:rgb(203, 191, 187) !important;
        color: white !important;
    }

    .portal-card {
        height: 500px;
        border-radius: 12px;
    }

    .portal-list {
        height: calc(100% - 56px);
        overflow-y: auto;
    }

    .portal-item {
        display: flex;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid #eee;
        cursor: pointer;
        transition: all 0.2s;
    }

    .portal-item:hover {
        background: rgba(134, 43, 13, 0.05);
    }

    .portal-avatar {
        width: 45px;
        height: 45px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #FFF3E4;
        border-radius: 8px;
        margin-right: 15px;
        color:rgb(211, 191, 184);
    }

    .portal-info {
        flex: 1;
    }

    .portal-name {
        font-weight: 600;
        color: #333;
    }

    .portal-role {
        color: #666;
    }

    .portal-messages {
        height: 400px;
        overflow-y: auto;
        padding: 20px;
        background: #FFF3E4;
    }

    .message-sent .message-content {
        background:rgb(221, 207, 202);
        color: white;
    }

    .message-received .message-content {
        background: white;
        color: #333;
    }

    .btn-custom {
        background:rgb(222, 208, 204);
        color: white;
    }

    .btn-custom:hover {
        background:rgb(242, 225, 219);
        color: white;
    }

    .empty-portal {
        text-align: center;
        color:rgb(164, 124, 125);
        padding: 40px 20px;
    }

    .empty-portal i {
        font-size: 48px;
        margin-bottom: 15px;
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="sidebar">
        <div class="logo-section">
            <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Logo Petugas">
            <div class="title">
                Dashboard Petugas<br>
                <span class="name"><?= htmlspecialchars($_SESSION['nama']) ?></span>
            </div>
        </div>
        <div class="menu-section">
            <a href="?menu=sekolah" class="<?= $menu=='sekolah'?'active':'' ?>">Data Sekolah</a>
            <a href="?menu=makanan" class="<?= $menu=='makanan'?'active':'' ?>">Data Makanan ke Sekolah</a>
            <a href="?menu=pengaduan" class="<?= $menu=='pengaduan'?'active':'' ?>">Pengaduan</a>
            <a href="?menu=komunikasi" id="menu-komunikasi-link" class="<?= $menu=='komunikasi'?'active':'' ?>">
                Portal Komunikasi
                <span id="notif-badge" style="display:none;background:#dc3545;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;margin-left:8px;">Baru</span>
            </a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="main-content">
        <div class="top-bar">
            <h3 class="section-title">
                <?php
                if ($menu=='sekolah') {
                    echo 'Data Sekolah';
                } elseif ($menu=='makanan') {
                    echo 'Data Makanan ke Sekolah';
                } elseif ($menu=='komunikasi') {
                    echo 'Portal Komunikasi';
                } elseif ($menu=='pengaduan') {
                    echo 'Data Pengaduan';
                }
                ?>
            </h3>
        </div>
        <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white d-flex align-items-center" style="border-left: 14px solidhsla(132, 62.40%, 33.30%, 0.69);">
            <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:rgba(0, 81, 44, 0.1);border-radius:50%;padding:10px;border:6px rgba(0, 81, 44, 0.1);">
            <div>
                <div class="fw-bold" style="font-size:1.5rem;">Program Makan Siang Gratis Prabowo</div>
                <div style="color:#;font-weight:500;">Dapatkan makan siang bergizi gratis untuk siswa sekolah! Pantau distribusi, menu, dan pengaduan di dashboard ini.</div>
            </div>
        </div>
        <?php if ($menu=='sekolah'): ?>
            <?php if (isset($_GET['success']) && $_GET['success']=='1'): ?>
                <div class="alert alert-success" role="alert" style="margin-bottom:18px;">
                    Data sekolah berhasil disimpan!
                </div>
            <?php endif; ?>

            <!-- Add button and section title -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="section-title mb-0">Data Sekolah</h3>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formSekolah">
                    <i class="fas fa-plus"></i> Tambah Data Sekolah
                </button>
            </div>

            <!-- Modal Form -->
            <div class="modal fade" id="formSekolah" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?= $edit_sekolah ? 'Edit' : 'Tambah' ?> Data Sekolah</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form method="post" id="form-sekolah">
                                <input type="hidden" name="id" value="<?= $edit_sekolah ? $edit_sekolah['id'] : '' ?>">
                                <div class="mb-3">
                                    <label class="form-label">Nama Sekolah</label>
                                    <input type="text" name="nama" class="form-control" required value="<?= $edit_sekolah ? htmlspecialchars($edit_sekolah['nama']) : '' ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Alamat</label>
                                    <input type="text" name="alamat" class="form-control" required value="<?= $edit_sekolah ? htmlspecialchars($edit_sekolah['alamat']) : '' ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Jenjang</label>
                                    <select name="jenjang" class="form-select" required>
                                        <option value="">Pilih Jenjang</option>
                                        <option value="SD" <?= $edit_sekolah && $edit_sekolah['jenjang']=='SD'?'selected':'' ?>>SD</option>
                                        <option value="SMP" <?= $edit_sekolah && $edit_sekolah['jenjang']=='SMP'?'selected':'' ?>>SMP</option>
                                        <option value="SMA" <?= $edit_sekolah && $edit_sekolah['jenjang']=='SMA'?'selected':'' ?>>SMA</option>
                                        <option value="SMK" <?= $edit_sekolah && $edit_sekolah['jenjang']=='SMK'?'selected':'' ?>>SMK</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Status Sekolah</label>
                                    <select name="status_sekolah" class="form-select" required>
                                        <option value="">Pilih Status</option>
                                        <option value="Negeri" <?= $edit_sekolah && $edit_sekolah['status_sekolah']=='Negeri'?'selected':'' ?>>Negeri</option>
                                        <option value="Swasta" <?= $edit_sekolah && $edit_sekolah['status_sekolah']=='Swasta'?'selected':'' ?>>Swasta</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Keterangan MBG</label>
                                    <select name="keterangan" id="keterangan_mbg" class="form-select" required onchange="toggleAlasanBelum()">
                                        <option value="Sudah" <?= $edit_sekolah && $edit_sekolah['keterangan']=='Sudah'?'selected':'' ?>>Sudah</option>
                                        <option value="Belum" <?= $edit_sekolah && $edit_sekolah['keterangan']=='Belum'?'selected':'' ?>>Belum</option>
                                    </select>
                                </div>
                                <div class="mb-3" id="alasan_belum_wrap" style="display:none;">
                                    <label class="form-label">Alasan Belum MBG</label>
                                    <input type="text" name="alasan_belum" id="alasan_belum" class="form-control" value="<?= $edit_sekolah && $edit_sekolah['keterangan']=='Belum' ? htmlspecialchars($edit_sekolah['alasan_belum']) : '' ?>">
                                </div>
                                <div class="text-end">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" name="save_sekolah" class="btn btn-success">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <h3 class="section-title" id="data-sekolah">Daftar Sekolah</h3>
            <form method="get" class="row g-2 mb-3">
                <input type="hidden" name="menu" value="sekolah">
                <div class="col-md-3">
                    <select name="filter_jenjang" class="form-select">
                        <option value="">Semua Jenjang</option>
                        <option value="SD" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SD'?'selected':'' ?>>SD</option>
                        <option value="SMP" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMP'?'selected':'' ?>>SMP</option>
                        <option value="SMA" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMA'?'selected':'' ?>>SMA</option>
                        <option value="SMK" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMK'?'selected':'' ?>>SMK</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="filter_status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="Negeri" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Negeri'?'selected':'' ?>>Negeri</option>
                        <option value="Swasta" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Swasta'?'selected':'' ?>>Swasta</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama/alamat..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                </div>
                <div class="col-md-2 d-grid">
                    <button type="submit" class="btn btn-success">Filter</button>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle bg-white">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Sekolah</th>
                            <th>Alamat</th>
                            <th>Jenjang</th>
                            <th>Status Sekolah</th>
                            <th>Keterangan MBG</th>
                            <th>Alasan Belum MBG</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    if ($data_sekolah && $data_sekolah->num_rows > 0) {
                        $data_sekolah->data_seek(0);
                        $no = 1 + $offset_sekolah;
                        while($row = $data_sekolah->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                <td><?= htmlspecialchars($row['alamat']) ?></td>
                                <td><?= isset($row['jenjang']) ? htmlspecialchars($row['jenjang']) : '-' ?></td>
                                <td><?= isset($row['status_sekolah']) ? htmlspecialchars($row['status_sekolah']) : '-' ?></td>
                                <td><?= isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                                <td><?= ($row['keterangan']=='Belum') ? htmlspecialchars($row['alasan_belum']) : '-' ?></td>
                                <td>
                                    <!-- Hapus tombol Edit dan Hapus -->
                                </td>
                            </tr>
                        <?php endwhile;
                    } else {
                        echo '<tr><td colspan="8" class="text-center text-danger">Tidak ada data sekolah.</td></tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>

            <?php
            // Pagination for data_sekolah
            $total_sekolah = $conn->query("SELECT COUNT(*) as total FROM user WHERE $whereSql")->fetch_assoc()['total'];
            $total_pages_sekolah = ceil($total_sekolah / $limit);
            if ($total_pages_sekolah > 1): ?>
            <nav>
              <ul class="pagination justify-content-center">
                <li class="page-item<?= $page_sekolah == 1 ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah-1 ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_pages_sekolah; $i++): ?>
                  <li class="page-item<?= $page_sekolah == $i ? ' active' : '' ?>">
                    <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $i ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item<?= $page_sekolah == $total_pages_sekolah ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah+1 ?>">Next</a>
                </li>
              </ul>
            </nav>
            <?php endif; ?>
        <?php elseif ($menu=='makanan'): ?>
            <!-- Add button -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="section-title mb-0">Status Distribusi Makanan</h3>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formMakanan">
                    <i class="fas fa-plus"></i> Tambah Data
                </button>
            </div>

            <!-- Filter Form -->
            <form method="get" class="row g-2 mb-3 align-items-center">
                <input type="hidden" name="menu" value="makanan">
                <div class="col-md-3">
                    <select name="filter_status_distribusi" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?= $status_filter=='all'||$status_filter==''?'selected':'' ?>>Semua Status</option>
                        <option value="Dijadwalkan" <?= $status_filter=='Dijadwalkan'?'selected':'' ?>>Dijadwalkan</option>
                        <option value="Dikirim" <?= $status_filter=='Dikirim'?'selected':'' ?>>Dikirim</option>
                        <option value="Diterima" <?= $status_filter=='Diterima'?'selected':'' ?>>Diterima</option>
                        <option value="Ditolak" <?= $status_filter=='Ditolak'?'selected':'' ?>>Ditolak</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Cari..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                </div>
                <div class="col-md-2 d-grid">
                    <button type="submit" class="btn btn-success">Filter</button>
                </div>
            </form>

            <!-- Modal Form -->
            <div class="modal fade" id="formMakanan" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?= $edit_makanan ? 'Edit' : 'Tambah' ?> Data Makanan ke Sekolah</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form method="post" id="form-makanan">
                                <input type="hidden" name="id" value="<?= $edit_makanan ? $edit_makanan['id'] : '' ?>">
                                <div class="mb-3">
                                    <label class="form-label">Nama Sekolah</label>
                                    <select name="sekolah_id" id="sekolah_id" class="form-select" required>
                                        <option value="">Pilih Sekolah</option>
                                        <?php
                                        $jsAlamat = [];
                                        $user_sekolah->data_seek(0);
                                        while($s = $user_sekolah->fetch_assoc()):
                                            $jsAlamat[$s['id']] = $s['alamat'];
                                        ?>
                                            <option value="<?= $s['id'] ?>" <?= $edit_makanan && $edit_makanan['sekolah_id']==$s['id']?'selected':'' ?>>
                                                <?= htmlspecialchars($s['nama']) ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Alamat Sekolah</label>
                                    <input type="text" name="alamat" id="alamat_sekolah" class="form-control" readonly>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Lauk/Menu</label>
                                    <input type="text" name="lauk_menu" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tanggal dan Waktu Kirim</label>
                                    <input type="datetime-local" name="tanggal_kirim" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Jumlah</label>
                                    <input type="number" name="jumlah" class="form-control" required>
                                </div>
                                <div class="text-end">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" name="save_makanan" class="btn btn-success">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table section -->
            <div class="table-responsive mb-4">
                <table class="table table-bordered table-striped align-middle bg-white">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Sekolah</th>
                            <th>Menu</th>
                            <th>Jadwal Kirim</th>
                            <th>Status</th>
                            <th>Jumlah</th>
                            <th>Konfirmasi</th>
                            <th>Keterangan Sekolah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Gunakan filter status_distribusi dan search pada query distribusi
                    $search_sql = '';
                    if (!empty($_GET['search'])) {
                        $search = $conn->real_escape_string($_GET['search']);
                        $search_sql = " AND (u.nama LIKE '%$search%' OR u.alamat LIKE '%$search%') ";
                    }
                    $distribusi = $conn->query("
                        SELECT d.*, m.sekolah_id, m.lauk_menu, m.jumlah, u.nama as sekolah_nama, u.alamat as sekolah_alamat
                        FROM distribusi_makanan d
                        JOIN makanan_kirim m ON d.makanan_id = m.id
                        JOIN user u ON m.sekolah_id = u.id
                        WHERE 1=1 $status_sql $search_sql
                        ORDER BY d.jadwal_kirim DESC
                        LIMIT $limit OFFSET $offset_makanan
                    ");
                    $no = 1 + $offset_makanan;
                    while($d = $distribusi->fetch_assoc()): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($d['sekolah_nama']) ?></td>
                            <td><?= htmlspecialchars($d['lauk_menu']) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($d['jadwal_kirim'])) ?></td>
                            <td><?= htmlspecialchars($d['status_distribusi']) ?></td>
                            <td><?= htmlspecialchars($d['jumlah']) ?></td>
                            <td><?= $d['konfirmasi_penerima'] ? date('d/m/Y H:i', strtotime($d['waktu_konfirmasi'])) : '-' ?></td>
                            <td><?= htmlspecialchars($d['catatan_sekolah'] ?? '-') ?></td>
                            <td>
                                <div class="dropdown mb-2">
                                    <select class="form-select form-select-sm" 
                                            onchange="updateStatus(<?= $d['id'] ?>, this.value)">
                                        <option value="">Pilih Status</option>
                                        <option value="Dijadwalkan" <?= $d['status_distribusi']=='Dijadwalkan'?'selected':''?>>Dijadwalkan</option>
                                        <option value="Dikirim" <?= $d['status_distribusi']=='Dikirim'?'selected':''?>>Dikirim</option>
                                        <option value="Diterima" <?= $d['status_distribusi']=='Diterima'?'selected':''?>>Diterima</option>
                                        <option value="Ditolak" <?= $d['status_distribusi']=='Ditolak'?'selected':''?>>Ditolak</option>
                                    </select>
                                </div>
                                
                                <div class="btn-group">
                                    <?php if($d['status_distribusi'] == 'Dikirim'): ?>
                                        <button type="button" class="btn btn-sm btn-success" onclick="updateStatus(<?= $d['id'] ?>, 'Diterima')">
                                            Terima
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="updateStatus(<?= $d['id'] ?>, 'Ditolak')">
                                            Tolak
                                        </button>
                                    <?php endif; ?>
                                    <!-- Tombol Hapus dihilangkan -->
                                    <!--
                                    <a href="?menu=makanan&hapus_distribusi=<?= $d['id'] ?>" 
                                       class="btn btn-sm btn-danger ms-1"
                                       onclick="return confirm('Yakin ingin menghapus data ini?')">
                                        Hapus
                                    </a>
                                    -->
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            // Pagination for makanan (perlu hitung ulang total jika filter aktif)
            $total_makanan_q = "SELECT COUNT(*) as total FROM distribusi_makanan d
                JOIN makanan_kirim m ON d.makanan_id = m.id
                JOIN user u ON m.sekolah_id = u.id
                WHERE 1=1 $status_sql $search_sql";
            $total_makanan = $conn->query($total_makanan_q)->fetch_assoc()['total'];
            $total_pages_makanan = ceil($total_makanan / $limit);
            if ($total_pages_makanan > 1): ?>
            <nav>
              <ul class="pagination justify-content-center">
                <li class="page-item<?= $page_makanan == 1 ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=makanan&page_makanan=<?= $page_makanan-1 ?>&filter_status_distribusi=<?= urlencode($status_filter) ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_pages_makanan; $i++): ?>
                  <li class="page-item<?= $page_makanan == $i ? ' active' : '' ?>">
                    <a class="page-link" href="?menu=makanan&page_makanan=<?= $i ?>&filter_status_distribusi=<?= urlencode($status_filter) ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item<?= $page_makanan == $total_pages_makanan ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=makanan&page_makanan=<?= $page_makanan+1 ?>&filter_status_distribusi=<?= urlencode($status_filter) ?>">Next</a>
                </li>
              </ul>
            </nav>
            <?php endif; ?>
        <?php elseif ($menu=='pengaduan'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="section-title mb-0">Data Pengaduan</h3>  
            </div>
            <!-- Filter Form: Select Status + Search -->
            <form method="get" class="row g-2 mb-3 align-items-center">
                <input type="hidden" name="menu" value="pengaduan">
                <div class="col-md-3">
                    <select name="filter_status_pengaduan" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?= $status_pengaduan_filter=='all'||$status_pengaduan_filter==''?'selected':'' ?>>Semua Status</option>
                        <option value="Belum Diproses" <?= $status_pengaduan_filter=='Belum Diproses'?'selected':'' ?>>Belum Diproses</option>
                        <option value="Diproses" <?= $status_pengaduan_filter=='Diproses'?'selected':'' ?>>Diproses</option>
                        <option value="Selesai" <?= $status_pengaduan_filter=='Selesai'?'selected':'' ?>>Selesai</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama pelapor..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                </div>
                <div class="col-md-2 d-grid">
                    <button type="submit" class="btn btn-success">Filter</button>
                </div>
            </form>
            <?php
            // Search hanya berdasarkan nama pelapor
            $search_pengaduan_sql = '';
            if (!empty($_GET['search'])) {
                $search_pengaduan = $conn->real_escape_string($_GET['search']);
                $search_pengaduan_sql = " AND user.nama LIKE '%$search_pengaduan%'";
            }
            $pengaduan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql ORDER BY tanggal DESC LIMIT $limit_pengaduan OFFSET $offset_pengaduan");
            $total_pengaduan = $conn->query("SELECT COUNT(*) as total FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql")->fetch_assoc()['total'];
            ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle bg-white">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Pelapor</th>
                    <th>Isi Pengaduan</th>
                    <th>Bukti Foto</th>
                    <th>Komentar</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1 + $offset_pengaduan;
            if ($pengaduan && $pengaduan->num_rows > 0) {
                while($row = $pengaduan->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['pelapor']) ?></td>
                        <td><?= htmlspecialchars($row['isi']) ?></td>
                        <td>
                            <?php if (!empty($row['foto'])): ?>
                                <a href="uploads/<?= htmlspecialchars($row['foto']) ?>" target="_blank">
                                    <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="foto" style="max-width:70px;max-height:70px;border-radius:6px;">
                                </a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= !empty($row['komentar']) ? nl2br(htmlspecialchars($row['komentar'])) : '<span class="text-muted">-</span>' ?>
                        </td>
                        <td><?= htmlspecialchars($row['tanggal']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                    </tr>
                <?php endwhile;
            } else {
                echo '<tr><td colspan="7" class="text-center text-danger">Tidak ada data pengaduan.</td></tr>';
            }
            ?>
            </tbody>
        </table>
    </div>
    <!-- Pagination -->
    <?php
    $total_pages_pengaduan = ceil($total_pengaduan / $limit_pengaduan);
    if ($total_pages_pengaduan > 1): ?>
    <nav>
      <ul class="pagination justify-content-center">
        <li class="page-item<?= $page_pengaduan == 1 ? ' disabled' : '' ?>">
          <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan-1 ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search=<?= urlencode(isset($_GET['search']) ? $_GET['search'] : '') ?>">Previous</a>
        </li>
        <?php for ($i = 1; $i <= $total_pages_pengaduan; $i++): ?>
          <li class="page-item<?= $page_pengaduan == $i ? ' active' : '' ?>">
            <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $i ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search=<?= urlencode(isset($_GET['search']) ? $_GET['search'] : '') ?>"><?= $i ?></a>
          </li>
        <?php endfor; ?>
        <li class="page-item<?= $page_pengaduan == $total_pages_pengaduan ? ' disabled' : '' ?>">
          <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan+1 ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search=<?= urlencode(isset($_GET['search']) ? $_GET['search'] : '') ?>">Next</a>
        </li>
      </ul>
    </nav>
    <?php endif; ?>
        <?php elseif ($menu=='komunikasi'): ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="card portal-card border-0 shadow-sm">
                        <div class="card-header bg-custom">
                            <h5 class="card-title text-white mb-0">
                                <i class="fas fa-users me-2"></i>Daftar Pengguna
                            </h5>
                        </div>
                        <div class="portal-list p-0">
                            <?php
                            $users = $conn->query("SELECT * FROM user WHERE role='pengguna' ORDER BY nama");
                            while($user = $users->fetch_assoc()): ?>
                                <div class="portal-item" onclick="loadChat(<?= $user['id'] ?>)">
                                    <div class="portal-avatar">
                                        <i class="fas fa-user-circle"></i>
                                    </div>
                                    <div class="portal-info">
                                        <div class="portal-name"><?= htmlspecialchars($user['nama']) ?></div>
                                        <small class="portal-role"><?= htmlspecialchars($user['role']) ?></small>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="card portal-card border-0 shadow-sm">
                        <div class="card-header bg-custom">
                            <h5 class="card-title text-white mb-0">
                                <i class="fas fa-comments me-2"></i>Percakapan
                            </h5>
                        </div>
                        <div class="portal-messages" id="chatBox">
                            <div class="empty-portal">
                                <i class="fas fa-comments mb-3"></i>
                                <p>Pilih pengguna untuk memulai percakapan</p>
                            </div>
                        </div>
                        <div class="card-footer bg-white">
                            <form id="chatForm" class="portal-form">
                                <input type="hidden" id="receiver_id" name="receiver_id">
                                <div class="input-group">
                                    <input type="text" id="messageInput" class="form-control" 
                                           placeholder="Ketik pesan..." autocomplete="off">
                                    <button type="submit" class="btn btn-custom">
                                        <i class="fas fa-paper-plane"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <style>
            .bg-custom {
                background: #862B0D !important;
                color: white !important;
            }

            .portal-card {
                height: 500px;
                border-radius: 12px;
            }

            .portal-list {
                height: calc(100% - 56px);
                overflow-y: auto;
            }

            .portal-item {
                display: flex;
                align-items: center;
                padding: 15px;
                border-bottom: 1px solid #eee;
                cursor: pointer;
                transition: all 0.2s;
            }

            .portal-item:hover {
                background: rgba(134, 43, 13, 0.05);
            }

            .portal-avatar {
                width: 45px;
                height: 45px;
                display: flex;
                align-items: center;
                justify-content: center;
                background: #FFF3E4;
                border-radius: 8px;
                margin-right: 15px;
                color: #862B0D;
            }

            .portal-info {
                flex: 1;
            }

            .portal-name {
                font-weight: 600;
                color: #333;
            }

            .portal-role {
                color: #666;
            }

            .portal-messages {
                height: 400px;
                overflow-y: auto;
                padding: 20px;
                background: #FFF3E4;
            }

            .message-sent .message-content {
                background: #862B0D;
                color: white;
            }

            .message-received .message-content {
                background: white;
                color: #333;
            }

            .btn-custom {
                background: #862B0D;
                color: white;
            }

            .btn-custom:hover {
                background: #6b2208;
                color: white;
            }

            .empty-portal {
                text-align: center;
                color: #A4907C;
                padding: 40px 20px;
            }

            .empty-portal i {
                font-size: 48px;
                margin-bottom: 15px;
            }
            </style>

            <!-- Keep existing script unchanged -->
            <script>
            function loadChat(userId) {
                document.getElementById('receiver_id').value = userId;
                fetch('load_chat.php?user_id=' + userId)
                    .then(response => response.text())
                    .then(html => {
                        document.getElementById('chatBox').innerHTML = html;
                        chatBox.scrollTop = chatBox.scrollHeight;
                    });
            }

            document.getElementById('chatForm').onsubmit = function(e) {
                e.preventDefault();
                let message = document.getElementById('messageInput').value;
                let receiver = document.getElementById('receiver_id').value;
                
                if(!message || !receiver) return;

                fetch('send_message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'message=' + encodeURIComponent(message) + '&receiver_id=' + receiver
                })
                .then(() => {
                    document.getElementById('messageInput').value = '';
                    loadChat(receiver);
                });
            }

            // Notifikasi pesan baru
            let lastNotifCount = 0;
            function checkNewMessages() {
                fetch('notif_pesan_petugas.php')
                    .then(res => res.json())
                    .then(data => {
                        const badge = document.getElementById('notif-badge');
                        if (data.unread > 0) {
                            badge.style.display = 'inline-block';
                            badge.textContent = 'Baru';
                            if (lastNotifCount !== data.unread) {
                                // Play sound or show alert only if count changed
                                if (lastNotifCount !== 0) {
                                    // Not first load
                                    if (window.Notification && Notification.permission === "granted") {
                                        new Notification("Pesan baru dari pengguna!");
                                    } else {
                                        // Fallback: alert kecil
                                        let notif = document.createElement('div');
                                        notif.textContent = "Pesan baru dari pengguna!";
                                        notif.style.position = 'fixed';
                                        notif.style.bottom = '30px';
                                        notif.style.right = '30px';
                                        notif.style.background = '#dc3545';
                                        notif.style.color = '#fff';
                                        notif.style.padding = '12px 20px';
                                        notif.style.borderRadius = '8px';
                                        notif.style.zIndex = 9999;
                                        notif.style.boxShadow = '0 2px 8px rgba(0,0,0,0.15)';
                                        document.body.appendChild(notif);
                                        setTimeout(()=>notif.remove(), 2500);
                                    }
                                }
                                lastNotifCount = data.unread;
                            }
                        } else {
                            badge.style.display = 'none';
                            lastNotifCount = 0;
                        }
                    });
            }
            if (window.Notification && Notification.permission !== "granted") {
                Notification.requestPermission();
            }
            setInterval(checkNewMessages, 4000);
            if (window.location.search.includes('menu=komunikasi')) {
                setTimeout(checkNewMessages, 1000);
            }
            </script>
        <?php endif; ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editSekolah(id) {
    fetch('get_sekolah.php?id=' + id)
        .then(response => response.json())
        .then(data => {
            document.querySelector('[name="id"]').value = data.id;
            document.querySelector('[name="nama"]').value = data.nama;
            document.querySelector('[name="alamat"]').value = data.alamat;
            document.querySelector('[name="jenjang"]').value = data.jenjang;
            document.querySelector('[name="status_sekolah"]').value = data.status_sekolah;
            document.querySelector('[name="keterangan"]').value = data.keterangan;
            document.querySelector('[name="alasan_belum"]').value = data.alasan_belum || '';
            
            // Show/hide alasan belum field based on keterangan
            toggleAlasanBelum();
            
            // Show modal
            var modal = new bootstrap.Modal(document.getElementById('formSekolah'));
            modal.show();
        });
}

function toggleAlasanBelum() {
    var keterangan = document.getElementById('keterangan_mbg').value;
    var alasanWrap = document.getElementById('alasan_belum_wrap');
    var alasanInput = document.getElementById('alasan_belum');
    
    if (keterangan == 'Belum') {
        alasanWrap.style.display = 'block';
        alasanInput.required = true;
    } else {
        alasanWrap.style.display = 'none';
        alasanInput.required = false;
    }
}

function updateStatus(id, status) {
    if (!status) return;
    let catatan = '';
    if (status !== 'Dikirim') {
        catatan = prompt('Catatan update status ke ' + status + ':', '');
        if (catatan === null) return;
    }
    // Create form data
    let formData = new URLSearchParams();
    formData.append('id', id);
    formData.append('status', status);
    formData.append('catatan', catatan);
    // Send request
    fetch('update_distribusi.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result.includes('success')) {
            window.location.reload();
        } else {
            alert('Gagal mengupdate status: ' + result);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating status: ' + error);
    });
}

var alamatSekolah = <?= json_encode($jsAlamat) ?>;
function setAlamatSekolah() {
    var val = document.getElementById('sekolah_id').value;
    document.getElementById('alamat_sekolah').value = alamatSekolah[val] || '';
}
document.getElementById('sekolah_id').addEventListener('change', setAlamatSekolah);
// Set alamat otomatis saat modal dibuka jika sudah ada value
if (document.getElementById('sekolah_id').value) {
    setAlamatSekolah();
}
</script>
</body>
</html>
