<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])) {
    die('Unauthorized');
}

$current_user = $_SESSION['user_id'];
$other_user = intval($_GET['user_id']);

$query = "SELECT k.*, u1.nama as sender_name, u1.role as sender_role 
          FROM komunikasi k
          JOIN user u1 ON k.sender_id = u1.id
          WHERE (k.sender_id = ? AND k.receiver_id = ?)
          OR (k.sender_id = ? AND k.receiver_id = ?)
          ORDER BY k.tanggal ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("iiii", $current_user, $other_user, $other_user, $current_user);
$stmt->execute();
$result = $stmt->get_result();

$currentSender = null;
$messages = [];

// Group messages by sender
while($row = $result->fetch_assoc()) {
    if ($currentSender !== $row['sender_id']) {
        $messages[] = [
            'sender_id' => $row['sender_id'],
            'sender_name' => $row['sender_name'],
            'sender_role' => $row['sender_role'],
            'messages' => []
        ];
        $currentSender = $row['sender_id'];
    }
    $messages[count($messages) - 1]['messages'][] = [
        'content' => $row['pesan'],
        'time' => date('H:i', strtotime($row['tanggal']))
    ];
}

echo '<link rel="stylesheet" href="chat.css">';
echo '<div class="chat-messages">';

foreach ($messages as $group): 
    $isMyMessage = $group['sender_id'] == $current_user;
    $messageClass = $isMyMessage ? 'sent' : 'received';
?>
    <div class="message-group">
        <?php foreach ($group['messages'] as $index => $msg): ?>
            <div class="message <?= $messageClass ?>">
                <?php if ($index === 0): ?>
                    <div class="message-sender">
                        <?= htmlspecialchars($group['sender_name']) ?> 
                        (<?= ucfirst($group['sender_role']) ?>)
                    </div>
                <?php endif; ?>
                <div class="message-bubble">
                    <div class="message-content">
                        <?= htmlspecialchars($msg['content']) ?>
                        <span class="message-time"><?= $msg['time'] ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach;

echo '</div>';
?>
