<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pengguna') {
    echo json_encode([]); exit;
}
$pengguna_id = $_SESSION['user_id'];
$data = [];
$res = $conn->query("SELECT pengirim_id, COUNT(*) as unread FROM pesan WHERE penerima_id=$pengguna_id AND status='Belum Dibaca' GROUP BY pengirim_id");
while($row = $res->fetch_assoc()) {
    $data[$row['pengirim_id']] = $row['unread'];
}
echo json_encode($data);
