<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])) {
    die('Unauthorized');
}

$sender_id = $_SESSION['user_id'];
$receiver_id = intval($_POST['receiver_id']);
$message = $_POST['message'];

$stmt = $conn->prepare("INSERT INTO komunikasi (sender_id, receiver_id, pesan) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $sender_id, $receiver_id, $message);
$stmt->execute();

echo 'success';
