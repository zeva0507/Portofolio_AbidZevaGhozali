<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

// Tambah user baru
if (isset($_POST['tambah_user'])) {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $stmt = $conn->prepare("INSERT INTO user (nama, username, password, role) VALUES (?, ?, ?, ?)");
    // Gunakan variabel, bukan $_POST langsung
    $stmt->bind_param("ssss", $nama, $username, $password, $role);
    $stmt->execute();
    $stmt->close();
    header('Location: dashboard_admin.php?menu=pengguna');
    exit;
}

// Edit user
if (isset($_POST['edit_user'])) {
    $id = intval($_POST['id']);
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $role = $_POST['role'];
    
    // Check if username exists for other users
    $check = $conn->prepare("SELECT id FROM user WHERE username = ? AND id != ?");
    $check->bind_param("si", $username, $id);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $_SESSION['error'] = "Username sudah digunakan!";
        header("Location: dashboard_admin.php?menu=pengguna");
        exit;
    }

    if (!empty($_POST['password'])) {
        // Update with new password
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE user SET nama=?, username=?, password=?, role=? WHERE id=?");
        $stmt->bind_param("ssssi", $nama, $username, $password, $role, $id);
    } else {
        // Update without changing password
        $stmt = $conn->prepare("UPDATE user SET nama=?, username=?, role=? WHERE id=?");
        $stmt->bind_param("sssi", $nama, $username, $role, $id);
    }
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Pengguna berhasil diupdate!";
    } else {
        $_SESSION['error'] = "Gagal mengupdate pengguna!";
    }
    $stmt->close();
    
    header("Location: dashboard_admin.php?menu=pengguna");
    exit;
}

// Delete user
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    
    if ($id != $_SESSION['user_id']) {
        $stmt = $conn->prepare("DELETE FROM user WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Pengguna berhasil dihapus!";
        } else {
            $_SESSION['error'] = "Gagal menghapus pengguna!";
        }
    } else {
        $_SESSION['error'] = "Tidak dapat menghapus akun sendiri!";
    }
    
    header("Location: dashboard_admin.php?menu=pengguna");
    exit;
}
?>
            $_SESSION['success'] = "Pengguna berhasil dihapus!";
        } else {
            $_SESSION['error'] = "Gagal menghapus pengguna!";
        }
    } else {
        $_SESSION['error'] = "Tidak dapat menghapus akun sendiri!";
    }
    
    header("Location: dashboard_admin.php?menu=pengguna");
    exit;
}
?>
