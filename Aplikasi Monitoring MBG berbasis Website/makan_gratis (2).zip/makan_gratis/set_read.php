<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id'])) exit('Unauthorized');
$user_id = intval($_GET['user_id']);
$my_id = intval($_SESSION['user_id']);
$conn->query("UPDATE pesan SET status='read' WHERE pengirim_id=$user_id AND penerima_id=$my_id AND status='unread'");
echo 'success';
