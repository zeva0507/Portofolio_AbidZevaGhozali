<?php
session_start();
include 'db.php';

// Cek apakah tabel user ada, jika tidak tampilkan pesan error ramah
$result = $conn->query("SHOW TABLES LIKE 'user'");
if (!$result || $result->num_rows == 0) {
    die('<div style="margin:40px auto;max-width:600px;padding:30px;background:#fff;border-radius:8px;border:1px solid #eee;font-family:sans-serif;font-size:18px;color:#b91c1c;text-align:center;">
        <b>Database Error:</b><br>
        Tabel <code>user</code> tidak ditemukan.<br>
        Silakan import database atau buat tabel <code>user</code> terlebih dahulu.<br>
        <br>
        <small>File: index.php</small>
    </div>');
}

if (isset($_SESSION['user_id'])) {
    // Redirect ke dashboard sesuai role
    if ($_SESSION['role'] == 'admin') {
        header('Location: dashboard_admin.php');
    } elseif ($_SESSION['role'] == 'sekolah') {
        header('Location: dashboard_sekolah.php');
    } elseif ($_SESSION['role'] == 'petugas') {
        header('Location: dashboard_petugas.php');
    } else {
        header('Location: dashboard_pengguna.php');
    }
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM user WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        // Cek jika password di database sudah ter-hash bcrypt
        if (
            password_verify($password, $row['password']) ||
            $password === $row['password'] // fallback jika password di database masih plain text
        ) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['nama'] = $row['nama']; // Add this line to store user's name
            if ($row['role'] == 'admin') {
                header('Location: dashboard_admin.php');
            } elseif ($row['role'] == 'sekolah') {
                header('Location: dashboard_sekolah.php');
            } elseif ($row['role'] == 'petugas') {
                header('Location: dashboard_petugas.php');
            } else {
                header('Location: dashboard_pengguna.php');
            }
            exit;
        }
    }
    $error = 'Username atau password salah!';
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Monitoring Makan Bergizi Gratis</title>
    <style>
        :root {
            --arya-green: #00512C;
            --arya-dark: #004024;
            --arya-light: #F5F5F5;
            --arya-gray: #707070;
            --arya-border: #E5E5E5;
        }

        body {
            margin: 0;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background: var(--arya-light);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            width: 400px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-header img {
            width: 90px;
            height: 90px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .login-header h1 {
            color: var(--arya-green);
            font-size: 24px;
            font-weight: 500;
            margin: 0 0 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .login-header .subtitle {
            color: var(--arya-gray);
            font-size: 14px;
            margin: 0;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            color: var(--arya-green);
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--arya-border);
            border-radius: 4px;
            font-size: 15px;
            color: var(--arya-gray);
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .input-group input:focus {
            border-color: var(--arya-green);
            outline: none;
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--arya-green);
            border: none;
            border-radius: 4px;
            color: #fff;
            font-size: 16px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn-login:hover {
            background: var(--arya-dark);
        }

        .login-footer {
            text-align: center;
            margin-top: 30px;
            color: var(--arya-gray);
            font-size: 13px;
        }

        .error {
            background: #FEE2E2;
            color: #DC2626;
            padding: 12px;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 20px;
            text-align: center;
        }

        .register-section {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid var(--arya-border);
        }

        .register-section p {
            color: var(--arya-gray);
            font-size: 14px;
            margin-bottom: 10px;
        }

        .btn-register {
            display: inline-block;
            padding: 10px 20px;
            background: transparent;
            border: 2px solid var(--arya-green);
            color: var(--arya-green);
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-register:hover {
            background: var(--arya-green);
            color: white;
        }
    </style>
</head>
<body class="bg-gradient">
    <div class="login-wrapper">
        <div class="login-card enhanced-card">
            <div class="login-header">
                <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Logo Makanan Sehat" class="login-logo pulse" style="width: 90px; height: 90px; padding: 10px;">
                <h1>Monitoring Makan Bergizi Gratis</h1>
                <p class="subtitle">Akses dashboard sesuai peran Anda</p>
            </div>
            <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <form method="post" class="login-form">
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" required autocomplete="off" placeholder="Masukkan username">
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" required placeholder="Masukkan password">
                </div>
                <button type="submit" class="btn-login">Login</button>
                <div class="register-section">
                    <p>Belum punya akun?</p>
                    <a href="register.php" class="btn-register">Daftar sebagai Pengguna</a>
                </div>
            </form>
            <div class="login-footer">
                <small>© <?= date('Y') ?> Makan Bergizi Gratis. All rights reserved.</small>
            </div>
        </div>
    </div>
</body>
</html>
