<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $lokasi = $_POST['lokasi'];
    $tanggal = $_POST['tanggal'];
    $keterangan = $_POST['keterangan'];
    $stmt = $conn->prepare("INSERT INTO event (nama, lokasi, tanggal, keterangan) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nama, $lokasi, $tanggal, $keterangan);
    $stmt->execute();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Event Makan Gratis</title>
</head>
<body>
    <h1>Tambah Event Makan Gratis</h1>
    <form method="post">
        <label>Nama Event: <input type="text" name="nama" required></label><br>
        <label>Lokasi: <input type="text" name="lokasi" required></label><br>
        <label>Tanggal: <input type="date" name="tanggal" required></label><br>
        <label>Keterangan: <textarea name="keterangan"></textarea></label><br>
        <button type="submit">Simpan</button>
    </form>
    <a href="index.php">Kembali</a>
</body>
</html>
