<?php
session_start();
include 'db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $alamat = $_POST['alamat'];

    // Validasi
    if ($password !== $confirm_password) {
        $error = 'Password tidak cocok!';
    } else {
        // Cek username sudah ada atau belum
        $stmt = $conn->prepare("SELECT id FROM user WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = 'Username sudah digunakan!';
        } else {
            // Insert user baru
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $role = 'pengguna'; // Set role default ke pengguna
            
            $stmt = $conn->prepare("INSERT INTO user (nama, username, password, role, alamat) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $nama, $username, $hashed_password, $role, $alamat);
            
            if ($stmt->execute()) {
                $success = 'Registrasi berhasil! Silahkan login.';
            } else {
                $error = 'Gagal melakukan registrasi!';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrasi Pengguna - Monitoring Makan Bergizi Gratis</title>
    <style>
        :root {
            --arya-green: #00512C;
            --arya-dark: #004024;
            --arya-light: #F5F5F5;
            --arya-gray: #707070;
            --arya-border: #E5E5E5;
        }

        body {
            margin: 0;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background: var(--arya-light);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .register-card {
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            width: 400px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .register-header img {
            width: 80px;
            height: 80px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .register-header h1 {
            color: var(--arya-green);
            font-size: 24px;
            font-weight: 500;
            margin: 0 0 10px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            color: var(--arya-green);
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--arya-border);
            border-radius: 4px;
            font-size: 15px;
            box-sizing: border-box;
        }

        .input-group input:focus {
            border-color: var(--arya-green);
            outline: none;
        }

        .btn-register {
            width: 100%;
            padding: 14px;
            background: var(--arya-green);
            border: none;
            border-radius: 4px;
            color: #fff;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.3s;
        }

        .btn-register:hover {
            background: var(--arya-dark);
        }

        .login-link {
            text-align: center;
            margin-top: 20px;
        }

        .login-link a {
            color: var(--arya-green);
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        .error {
            background: #FEE2E2;
            color: #DC2626;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success {
            background: #D1FAE5;
            color: #059669;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="register-header">
            <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Logo">
            <h1>Registrasi Pengguna</h1>
            <p>Program Makan Bergizi Gratis</p>
        </div>
        
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="input-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama" required>
            </div>
            
            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" required>
            </div>
            
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            
            <div class="input-group">
                <label>Konfirmasi Password</label>
                <input type="password" name="confirm_password" required>
            </div>
            
            <div class="input-group">
                <label>Alamat</label>
                <input type="text" name="alamat" required>
            </div>

            <button type="submit" class="btn-register">Daftar</button>
        </form>

        <div class="login-link">
            Sudah punya akun? <a href="index.php">Login di sini</a>
        </div>
    </div>
</body>
</html>
