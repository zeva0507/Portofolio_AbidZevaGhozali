<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'sekolah') {
    header('Location: index.php');
    exit;
}
$sekolah_id = $_SESSION['user_id'];

// Menu aktif
$menu = isset($_GET['menu']) ? $_GET['menu'] : 'pengaduan';

// Proses tambah pengaduan
if ($menu == 'pengaduan' && isset($_POST['save_pengaduan'])) {
    $user_id = $sekolah_id;
    $isi = $_POST['isi'];
    $status = 'Belum Diproses';
    $foto = null;
    // Proses upload foto jika ada
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nama_file = 'pengaduan_' . time() . '_' . rand(1000,9999) . '.' . $ext;
        $target_file = $target_dir . $nama_file;
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
            $foto = $nama_file;
        }
    }
    $stmt = $conn->prepare("INSERT INTO pengaduan (user_id, isi, status, foto) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $isi, $status, $foto);
    $stmt->execute();
    header("Location: dashboard_sekolah.php?menu=pengaduan");
    exit;
}

// Proses tambah sekolah
if ($menu == 'sekolah' && isset($_POST['save_sekolah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $jenjang = $_POST['jenjang'];
    $status_sekolah = $_POST['status_sekolah'];
    $keterangan = $_POST['keterangan'];
    $alasan_belum = isset($_POST['alasan_belum']) ? $_POST['alasan_belum'] : '';
    $username = uniqid('sekolah');
    $password = password_hash('12345', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO user (nama, alamat, jenjang, status_sekolah, keterangan, alasan_belum, role, username, password) VALUES (?, ?, ?, ?, ?, ?, 'sekolah', ?, ?)");
    $stmt->bind_param("ssssssss", $nama, $alamat, $jenjang, $status_sekolah, $keterangan, $alasan_belum, $username, $password);
    $stmt->execute();
    header("Location: dashboard_sekolah.php?menu=sekolah");
    exit;
}

// --- PAGINATION SETUP ---
$page_pengaduan = isset($_GET['page_pengaduan']) ? max(1, intval($_GET['page_pengaduan'])) : 1;
$page_sekolah = isset($_GET['page_sekolah']) ? max(1, intval($_GET['page_sekolah'])) : 1;
$page_distribusi = isset($_GET['page_distribusi']) ? max(1, intval($_GET['page_distribusi'])) : 1;
$page_komunikasi = isset($_GET['page_komunikasi']) ? max(1, intval($_GET['page_komunikasi'])) : 1;
$limit = 5;
$offset_pengaduan = ($page_pengaduan - 1) * $limit;
$offset_sekolah = ($page_sekolah - 1) * $limit;
$offset_distribusi = ($page_distribusi - 1) * $limit;
$offset_komunikasi = ($page_komunikasi - 1) * $limit;

// Ambil event milik sekolah ini
// Ambil data pengaduan & sekolah untuk menu
$total_pengaduan = $conn->query("SELECT COUNT(*) as total FROM pengaduan")->fetch_assoc()['total'];
$pengaduan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id ORDER BY tanggal DESC LIMIT $limit OFFSET $offset_pengaduan");

$total_user = $conn->query("SELECT COUNT(*) as total FROM user WHERE role='sekolah'")->fetch_assoc()['total'];
$user = $conn->query("SELECT * FROM user WHERE role='sekolah' ORDER BY nama LIMIT $limit OFFSET $offset_sekolah");

$total_distribusi = $conn->query("
    SELECT COUNT(*) as total
    FROM distribusi_makanan d
    JOIN makanan_kirim m ON d.makanan_id = m.id
    WHERE m.sekolah_id = $sekolah_id
")->fetch_assoc()['total'];
$distribusi = $conn->query("
    SELECT d.*, m.lauk_menu, m.jumlah 
    FROM distribusi_makanan d
    JOIN makanan_kirim m ON d.makanan_id = m.id 
    WHERE m.sekolah_id = $sekolah_id
    ORDER BY d.jadwal_kirim DESC
    LIMIT $limit OFFSET $offset_distribusi
");

$total_pesan = $conn->query("SELECT COUNT(*) as total FROM pesan WHERE pengirim_id = $sekolah_id")->fetch_assoc()['total'];
$pesan_terkirim = $conn->query("
    SELECT p.*, u.nama as penerima 
    FROM pesan p 
    JOIN user u ON p.penerima_id = u.id 
    WHERE p.pengirim_id = $sekolah_id
    ORDER BY p.tanggal DESC
    LIMIT $limit OFFSET $offset_komunikasi
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Sekolah</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="includes/action_buttons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
    :root {
        --arya-green: #00512C;
        --arya-dark: #004024;
        --arya-light: #F5F5F5;
        --arya-gray: #707070;
        --arya-border: #E5E5E5;
    }

    body {
        background: var(--arya-light);
        font-family: 'Helvetica Neue', Arial, sans-serif;
    }

    table, .table, .table th, .table td {
        font-family: 'Poppins', sans-serif !important;
        font-size: 14px !important;
    }
    .table th, th {
        font-weight: 600 !important;
        color: #2c3e50;
    }
    .table td, td {
        font-weight: 400 !important;
        color: #333;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }

    .sidebar {
        background: var(--arya-green);
        padding: 25px;
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
    }

    .sidebar .logo-section {
        padding-bottom: 25px;
        margin-bottom: 25px;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        text-align: center;
    }

    .sidebar .logo-section img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        padding: 10px;
        background: rgba(255,255,255,0.1);
        margin-bottom: 15px;
    }

    .sidebar .logo-section .title {
        color: #fff;
        font-size: 20px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .sidebar .menu-section a {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        color: rgba(255,255,255,0.8);
        text-decoration: none;
        font-size: 15px;
        border-radius: 6px;
        margin-bottom: 8px;
        transition: all 0.3s ease;
    }

    .sidebar .menu-section a:hover,
    .sidebar .menu-section a.active {
        background: rgba(255,255,255,0.1);
        color: #fff;
    }

    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 30px;
    }

    .section-title {
        font-size: 24px;
        font-weight: 500;
        color: var(--arya-green);
        margin: 30px 0 20px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .form-admin {
        background: #fff;
        border-radius: 8px;
        padding: 25px;
        margin-bottom: 30px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        border: 1px solid var(--arya-border);
    }

    .form-admin input,
    .form-admin select,
    .form-admin textarea {
        width: 100%;
        padding: 12px 15px;
        margin-bottom: 15px;
        border: 1px solid var(--arya-border);
        border-radius: 6px;
        background: #fff;
        color: #333;
        font-size: 14px;
    }

    .form-admin input::placeholder,
    .form-admin select::placeholder,
    .form-admin textarea::placeholder {
        color: var(--arya-gray);
    }

    .form-admin label {
        color: var(--arya-green);
        font-size: 14px;
        font-weight: 500;
        margin-bottom: 8px;
        display: block;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .form-admin button {
        background: var(--arya-green);
        color: #fff;
        border: none;
        padding: 12px 30px;
        font-size: 14px;
        font-weight: 600;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s;
        min-width: 150px;
        text-align: center;
        display: inline-block;
    }

    .form-admin button:hover {
        background: var(--arya-dark);
    }

    .table {
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .table thead th {
        background: var(--arya-green);
        color: #fff;
        font-weight: 500;
        text-transform: uppercase;
        font-size: 13px;
        letter-spacing: 0.5px;
        padding: 15px;
    }

    .table tbody td {
        padding: 12px 15px;
        border-bottom: 1px solid var(--arya-border);
        color: var(--arya-gray);
    }

    .banner-makan-gratis {
        background: #fff;
        padding: 25px;
        border-radius: 8px;
        border-left: 6px solid var(--arya-green);
        margin-bottom: 30px;
        display: flex;
        align-items: center;
    }

    .banner-makan-gratis .fw-bold {
        color: #333; /* Ubah ke hitam */
    }

    .banner-desc {
        color: #555; /* Warna teks deskripsi juga hitam tapi lebih terang */
        font-weight: 500;
    }

    .action-buttons {
        display: flex;
        gap: 10px;
    }

    .btn-edit,
    .btn-delete {
        display: inline-block;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 14px;
        text-align: center;
        transition: background 0.3s;
    }

    .btn-edit {
        background: #007bff;
        color: #fff;
    }

    .btn-edit:hover {
        background: #0056b3;
    }

    .btn-delete {
        background: #dc3545;
        color: #fff;
    }

    .btn-delete:hover {
        background: #c82333;
    }

    .btn i {
        margin-right: 5px;
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="sidebar">
        <div class="logo-section">
            <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Logo Sekolah">
            <div class="title">
                Dashboard Sekolah<br>
                <span class="name"><?= htmlspecialchars($_SESSION['nama']) ?></span>
            </div>
        </div>
        <div class="menu-section">
            <a href="?menu=pengaduan" class="<?= $menu=='pengaduan'?'active':'' ?>">Pengaduan</a>
            <a href="?menu=sekolah" class="<?= $menu=='sekolah'?'active':'' ?>">Data Sekolah</a>
            <a href="?menu=distribusi" class="<?= $menu=='distribusi'?'active':'' ?>">Distribusi Makanan</a>
            <a href="?menu=komunikasi" class="<?= $menu=='komunikasi'?'active':'' ?>">Portal Komunikasi</a>
            <a href="?menu=cetak_laporan" class="<?= $menu=='cetak_laporan'?'active':'' ?>">Cetak Laporan</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
    <div class="main-content">
        <?php if ($menu=='distribusi'): ?>
            <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white d-flex align-items-center" style="border-left: 6px solid var(--arya-green);">
                <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:#fff;border-radius:50%;padding:10px;border:6px solid var(--arya-green);">
                <div>
                    <div class="fw-bold" style="font-size:1.5rem;color:var(--arya-green);">Program Makan Siang Gratis</div>
                    <div style="color:var(--arya-gray);font-weight:500;">Dapatkan makan siang bergizi gratis untuk siswa sekolah!</div>
                </div>
            </div>

            <h3 class="section-title">Konfirmasi Penerimaan Makanan</h3>
            <!-- Filter Form: Select Status Distribusi -->
            <form method="get" class="row g-2 mb-3 align-items-center">
                <input type="hidden" name="menu" value="distribusi">
                <div class="col-md-3">
                    <select name="filter_status_distribusi" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?= (!isset($_GET['filter_status_distribusi']) || $_GET['filter_status_distribusi']=='all')?'selected':'' ?>>Semua Status</option>
                        <option value="Dikirim" <?= (isset($_GET['filter_status_distribusi']) && $_GET['filter_status_distribusi']=='Dikirim')?'selected':'' ?>>Dikirim</option>
                        <option value="Diterima" <?= (isset($_GET['filter_status_distribusi']) && $_GET['filter_status_distribusi']=='Diterima')?'selected':'' ?>>Diterima</option>
                        <option value="Ditolak" <?= (isset($_GET['filter_status_distribusi']) && $_GET['filter_status_distribusi']=='Ditolak')?'selected':'' ?>>Ditolak</option>
                    </select>
                </div>
            </form>
            <!-- END Filter Form -->

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle bg-white">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Menu</th>
                            <th>Jadwal Kirim</th>
                            <th>Status</th>
                            <th>Jumlah</th>
                            <th>Konfirmasi</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Query distribusi dengan LIMIT dan OFFSET agar hanya 5 baris per halaman
                    $filter_status_distribusi = isset($_GET['filter_status_distribusi']) ? $_GET['filter_status_distribusi'] : 'all';
                    $status_distribusi_sql = '';
                    if ($filter_status_distribusi && $filter_status_distribusi != 'all') {
                        $status_distribusi_sql = " AND d.status_distribusi = '".$conn->real_escape_string($filter_status_distribusi)."' ";
                    }
                    $total_distribusi = $conn->query("
                        SELECT COUNT(*) as total
                        FROM distribusi_makanan d
                        JOIN makanan_kirim m ON d.makanan_id = m.id
                        WHERE m.sekolah_id = $sekolah_id $status_distribusi_sql
                    ")->fetch_assoc()['total'];
                    $distribusi = $conn->query("
                        SELECT d.*, m.lauk_menu, m.jumlah 
                        FROM distribusi_makanan d
                        JOIN makanan_kirim m ON d.makanan_id = m.id 
                        WHERE m.sekolah_id = $sekolah_id $status_distribusi_sql
                        ORDER BY d.jadwal_kirim DESC
                        LIMIT $limit OFFSET $offset_distribusi
                    ");

                    $no = 1 + $offset_distribusi;
                    while($d = $distribusi->fetch_assoc()): 
                        $statusClass = '';
                        switch($d['status_distribusi']) {
                            case 'Dikirim': $statusClass = 'bg-primary text-white'; break;
                            case 'Diterima': $statusClass = 'bg-success text-white'; break;
                            case 'Ditolak': $statusClass = 'bg-danger text-white'; break;
                            default: $statusClass = 'bg-secondary text-white';
                        }
                    ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($d['lauk_menu']) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($d['jadwal_kirim'])) ?></td>
                            <td><span class="badge <?= $statusClass ?>"><?= htmlspecialchars($d['status_distribusi']) ?></span></td>
                            <td><?= htmlspecialchars($d['jumlah']) ?></td>
                            <td>
                                <?php if($d['konfirmasi_penerima']): ?>
                                    <small class="text-success">Dikonfirmasi:<br><?= date('d/m/Y H:i', strtotime($d['waktu_konfirmasi'])) ?></small>
                                <?php else: ?>
                                    <small class="text-secondary">Belum dikonfirmasi</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($d['status_distribusi'] == 'Dikirim'): ?>
                                    <button class="btn btn-success btn-sm" onclick="konfirmasiTerima(<?= $d['id'] ?>)">Konfirmasi Terima</button>
                                    <button class="btn btn-danger btn-sm" onclick="konfirmasiTolak(<?= $d['id'] ?>)">Tolak</button>
                                <?php elseif($d['status_distribusi'] == 'Diterima'): ?>
                                    <span class="badge bg-success">Diterima</span>
                                <?php elseif($d['status_distribusi'] == 'Ditolak'): ?>
                                    <span class="badge bg-danger">Ditolak</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            $total_pages_distribusi = ceil($total_distribusi / $limit);
            if ($total_pages_distribusi > 1): ?>
            <nav>
              <ul class="pagination justify-content-center mt-3">
                <li class="page-item<?= $page_distribusi == 1 ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=distribusi&page_distribusi=<?= $page_distribusi-1 ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_pages_distribusi; $i++): ?>
                  <li class="page-item<?= $page_distribusi == $i ? ' active' : '' ?>">
                    <a class="page-link" href="?menu=distribusi&page_distribusi=<?= $i ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item<?= $page_distribusi == $total_pages_distribusi ? ' disabled' : '' ?>">
                  <a class="page-link" href="?menu=distribusi&page_distribusi=<?= $page_distribusi+1 ?>">Next</a>
                </li>
              </ul>
            </nav>
            <?php endif; ?>
            <script>
            function konfirmasiTerima(id) {
                let konfirmasi = prompt('Pesan konfirmasi penerimaan:', 'Makanan diterima dengan baik');
                if (konfirmasi) {
                    submitKonfirmasi(id, 'Diterima', konfirmasi);
                }
            }

            function konfirmasiTolak(id) {
                let alasan = prompt('Alasan penolakan:', '');
                if (alasan) {
                    submitKonfirmasi(id, 'Ditolak', alasan);
                }
            }

            function submitKonfirmasi(id, status, pesan) {
                fetch('konfirmasi_distribusi.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `id=${id}&status=${status}&pesan=${pesan}`
                })
                .then(response => response.text())
                .then(() => location.reload())
                .catch(error => alert('Error updating confirmation'));
            }
            </script>
        <?php endif; ?>
        <div class="container py-4">
            <?php if ($menu=='pengaduan'): ?>
                <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white d-flex align-items-center" style="border-left: 6px solid var(--arya-green);">
                    <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:#fff;border-radius:50%;padding:10px;border:6px solid var(--arya-green);">
                    <div>
                        <div class="fw-bold" style="font-size:1.5rem;color:var(--arya-green);">Program Makan Siang Gratis</div>
                        <div style="color:var(--arya-gray);font-weight:500;">Dapatkan makan siang bergizi gratis untuk siswa sekolah!</div>
                    </div>
                </div>
                <!-- Title and Add Button -->
                <div class="row align-items-center mb-4">
                    <div class="col-md-6">
                        <h3 class="section-title mb-0">Data Pengaduan</h3>
                    </div>
                    <div class="col-md-6 text-end">
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formPengaduan">
                            <i class="fas fa-plus"></i> Tambah Pengaduan
                        </button>
                    </div>
                </div>

                <!-- Filter Form: Select Status + Search -->
                <form method="get" class="row g-2 mb-3 align-items-center">
                    <input type="hidden" name="menu" value="pengaduan">
                    <div class="col-md-3">
                        <select name="filter_status_pengaduan" class="form-select" onchange="this.form.submit()">
                            <option value="all" <?= (isset($_GET['filter_status_pengaduan']) && $_GET['filter_status_pengaduan']=='all')||!isset($_GET['filter_status_pengaduan'])?'selected':'' ?>>Semua Status</option>
                            <option value="Belum Diproses" <?= (isset($_GET['filter_status_pengaduan']) && $_GET['filter_status_pengaduan']=='Belum Diproses')?'selected':'' ?>>Belum Diproses</option>
                            <option value="Diproses" <?= (isset($_GET['filter_status_pengaduan']) && $_GET['filter_status_pengaduan']=='Diproses')?'selected':'' ?>>Diproses</option>
                            <option value="Selesai" <?= (isset($_GET['filter_status_pengaduan']) && $_GET['filter_status_pengaduan']=='Selesai')?'selected':'' ?>>Selesai</option>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <input type="text" name="search_pengaduan" class="form-control" placeholder="Cari nama pelapor/isi pengaduan..." value="<?= isset($_GET['search_pengaduan']) ? htmlspecialchars($_GET['search_pengaduan']) : '' ?>">
                    </div>
                    <div class="col-md-2 d-grid">
                        <button type="submit" class="btn btn-success">Filter</button>
                    </div>
                </form>

                <?php
                // Filter & search for pengaduan
                $status_pengaduan_filter = isset($_GET['filter_status_pengaduan']) ? $_GET['filter_status_pengaduan'] : '';
                $status_pengaduan_sql = '';
                if ($status_pengaduan_filter && $status_pengaduan_filter != 'all') {
                    $status_pengaduan_sql = " AND pengaduan.status = '".$conn->real_escape_string($status_pengaduan_filter)."' ";
                }
                $search_pengaduan_sql = '';
                if (!empty($_GET['search_pengaduan'])) {
                    $search_pengaduan = $conn->real_escape_string($_GET['search_pengaduan']);
                    $search_pengaduan_sql = " AND (user.nama LIKE '%$search_pengaduan%' OR pengaduan.isi LIKE '%$search_pengaduan%')";
                }
                $total_pengaduan = $conn->query("SELECT COUNT(*) as total FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql")->fetch_assoc()['total'];
                $pengaduan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id WHERE 1=1 $status_pengaduan_sql $search_pengaduan_sql ORDER BY tanggal DESC LIMIT $limit OFFSET $offset_pengaduan");
                ?>

                <!-- Modal Form -->
                <div class="modal fade" id="formPengaduan" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Tambah Pengaduan</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <!-- Tambahkan enctype untuk upload file -->
                                <form method="post" class="form-admin" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label class="form-label">Isi Pengaduan</label>
                                        <textarea name="isi" class="form-control" required rows="4"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Foto (opsional)</label>
                                        <input type="file" name="foto" class="form-control" accept="image/*">
                                    </div>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" name="save_pengaduan" class="btn btn-success">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Table section -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle bg-white">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Pelapor</th>
                                <th>Isi Pengaduan</th>
                                <th>Bukti Foto</th>
                                <th>Komentar</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1 + $offset_pengaduan; while($row = $pengaduan->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['pelapor']) ?></td>
                                <td><?= htmlspecialchars($row['isi']) ?></td>
                                <td>
                                    <?php if (!empty($row['foto'])): ?>
                                        <a href="uploads/<?= htmlspecialchars($row['foto']) ?>" target="_blank">
                                            <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="foto" style="max-width:70px;max-height:70px;border-radius:6px;">
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= !empty($row['komentar']) ? nl2br(htmlspecialchars($row['komentar'])) : '<span class="text-muted">-</span>' ?>
                                </td>
                                <td><?= htmlspecialchars($row['tanggal']) ?></td>
                                <td><?= htmlspecialchars($row['status']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php
                $total_pages_pengaduan = ceil($total_pengaduan / $limit);
                if ($total_pages_pengaduan > 1): ?>
                <nav>
                  <ul class="pagination justify-content-center">
                    <li class="page-item<?= $page_pengaduan == 1 ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan-1 ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search_pengaduan=<?= urlencode(isset($_GET['search_pengaduan']) ? $_GET['search_pengaduan'] : '') ?>">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages_pengaduan; $i++): ?>
                      <li class="page-item<?= $page_pengaduan == $i ? ' active' : '' ?>">
                        <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $i ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search_pengaduan=<?= urlencode(isset($_GET['search_pengaduan']) ? $_GET['search_pengaduan'] : '') ?>"><?= $i ?></a>
                      </li>
                    <?php endfor; ?>
                    <li class="page-item<?= $page_pengaduan == $total_pages_pengaduan ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=pengaduan&page_pengaduan=<?= $page_pengaduan+1 ?>&filter_status_pengaduan=<?= urlencode($status_pengaduan_filter) ?>&search_pengaduan=<?= urlencode(isset($_GET['search_pengaduan']) ? $_GET['search_pengaduan'] : '') ?>">Next</a>
                    </li>
                  </ul>
                </nav>
                <?php endif; ?>
            <?php elseif ($menu=='sekolah'): ?>
                <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white d-flex align-items-center" style="border-left: 6px solid var(--arya-green);">
                    <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:#fff;border-radius:50%;padding:10px;border:6px solid var(--arya-green);">
                    <div>
                        <div class="fw-bold" style="font-size:1.5rem;color:var(--arya-green);">Program Makan Siang Gratis</div>
                        <div style="color:var(--arya-gray);font-weight:500;">Dapatkan makan siang bergizi gratis untuk siswa sekolah!</div>
                    </div>
                </div>
                <h3 class="section-title">Daftar Data Sekolah</h3>
                <form method="get" class="row g-2 mb-3">
                    <input type="hidden" name="menu" value="sekolah">
                    <div class="col-md-3">
                        <select name="filter_jenjang" class="form-select">
                            <option value="">Semua Jenjang</option>
                            <option value="SD" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SD'?'selected':'' ?>>SD</option>
                            <option value="SMP" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMP'?'selected':'' ?>>SMP</option>
                            <option value="SMA" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMA'?'selected':'' ?>>SMA</option>
                            <option value="SMK" <?= isset($_GET['filter_jenjang']) && $_GET['filter_jenjang']=='SMK'?'selected':'' ?>>SMK</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="filter_status" class="form-select">
                            <option value="">Semua Status</option>
                            <option value="Negeri" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Negeri'?'selected':'' ?>>Negeri</option>
                            <option value="Swasta" <?= isset($_GET['filter_status']) && $_GET['filter_status']=='Swasta'?'selected':'' ?>>Swasta</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Cari nama/alamat..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                    </div>
                    <div class="col-md-2 d-grid">
                        <button type="submit" class="btn btn-success" style="background:var(--arya-green);border:none;">Filter</button>
                    </div>
                </form>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle bg-white">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Nama Sekolah</th>
                                <th>Alamat</th>
                                <th>Jenjang</th>
                                <th>Status Sekolah</th>
                                <th>Keterangan MBG</th>
                                <th>Alasan Belum MBG</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $no = 1 + $offset_sekolah;
                        
                        // Add this before displaying the table
                        $where = ["role='sekolah'"]; // Base condition

                        if (!empty($_GET['filter_jenjang'])) {
                            $jenjang = $conn->real_escape_string($_GET['filter_jenjang']);
                            $where[] = "jenjang='$jenjang'";
                        }

                        if (!empty($_GET['filter_status'])) {
                            $status = $conn->real_escape_string($_GET['filter_status']);
                            $where[] = "status_sekolah='$status'";
                        }

                        if (!empty($_GET['search'])) {
                            $search = $conn->real_escape_string($_GET['search']);
                            $where[] = "(nama LIKE '%$search%' OR alamat LIKE '%$search%')";
                        }

                        $whereSql = implode(" AND ", $where);
                        $user = $conn->query("SELECT * FROM user WHERE $whereSql ORDER BY nama LIMIT $limit OFFSET $offset_sekolah");
                        $user->data_seek(0);
                        while($row = $user->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                <td><?= htmlspecialchars($row['alamat']) ?></td>
                                <td><?= isset($row['jenjang']) ? htmlspecialchars($row['jenjang']) : '-' ?></td>
                                <td><?= isset($row['status_sekolah']) ? htmlspecialchars($row['status_sekolah']) : '-' ?></td>
                                <td><?= isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                                <td><?= ($row['keterangan']=='Belum') ? htmlspecialchars($row['alasan_belum']) : '-' ?></td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php
                $total_pages_sekolah = ceil($total_user / $limit);
                if ($total_pages_sekolah > 1): ?>
                <nav>
                  <ul class="pagination justify-content-center">
                    <li class="page-item<?= $page_sekolah == 1 ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah-1 ?>">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages_sekolah; $i++): ?>
                      <li class="page-item<?= $page_sekolah == $i ? ' active' : '' ?>">
                        <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $i ?>"><?= $i ?></a>
                      </li>
                    <?php endfor; ?>
                    <li class="page-item<?= $page_sekolah == $total_pages_sekolah ? ' disabled' : '' ?>">
                      <a class="page-link" href="?menu=sekolah&page_sekolah=<?= $page_sekolah+1 ?>">Next</a>
                    </li>
                  </ul>
                </nav>
                <?php endif; ?>
            <?php elseif ($menu=='cetak_laporan'): ?>
                <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white d-flex align-items-center" style="border-left: 6px solid var(--arya-green);">
                    <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:#fff;border-radius:50%;padding:10px;border:6px solid var(--arya-green);">
                    <div>
                        <div class="fw-bold" style="font-size:1.5rem;color:var(--arya-green);">Program Makan Siang Gratis</div>
                        <div style="color:var(--arya-gray);font-weight:500;">Dapatkan makan siang bergizi gratis untuk siswa sekolah!</div>
                    </div>
                </div>
                <h3 class="section-title">Cetak Laporan</h3>
                <form method="get" class="mb-3">
                    <input type="hidden" name="menu" value="cetak_laporan">
                    <select name="laporan" required class="form-select" style="max-width:300px;display:inline-block;">
                        <option value="">Pilih Data Laporan</option>
                        <option value="sekolah" <?= (isset($_GET['laporan']) && $_GET['laporan']=='sekolah')?'selected':'' ?>>Data Sekolah</option>
                        <option value="pengaduan" <?= (isset($_GET['laporan']) && $_GET['laporan']=='pengaduan')?'selected':'' ?>>Pengaduan</option>
                        <option value="komunikasi" <?= (isset($_GET['laporan']) && $_GET['laporan']=='komunikasi')?'selected':'' ?>>Portal Komunikasi</option>
                        <option value="distribusi" <?= (isset($_GET['laporan']) && $_GET['laporan']=='distribusi')?'selected':'' ?>>Distribusi Makanan</option>
                    </select>
                    <button type="submit" class="btn btn-success ms-2">Tampilkan</button>
                </form>
                <?php if (isset($_GET['laporan']) && $_GET['laporan']=='sekolah'): ?>
                    <h3 class="section-title">Laporan Data Sekolah</h3>
                    <?php $laporan = $conn->query("SELECT * FROM user WHERE role='sekolah' ORDER BY nama"); ?>
                    <div class="table-responsive">
                        <table id="table-laporan" class="table table-bordered table-striped align-middle bg-white">
                            <thead class="table-light">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Sekolah</th>
                                    <th>Alamat</th>
                                    <th>Jenjang</th>
                                    <th>Status Sekolah</th>
                                    <th>Keterangan MBG</th>
                                    <th>Alasan Belum MBG</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $no=1; while($row = $laporan->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['nama']) ?></td>
                                    <td><?= htmlspecialchars($row['alamat']) ?></td>
                                    <td><?= isset($row['jenjang']) ? htmlspecialchars($row['jenjang']) : '-' ?></td>
                                    <td><?= isset($row['status_sekolah']) ? htmlspecialchars($row['status_sekolah']) : '-' ?></td>
                                    <td><?= isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                                    <td><?= ($row['keterangan']=='Belum') ? htmlspecialchars($row['alasan_belum']) : '-' ?></td>
                                </tr>
                            <?php endwhile; ?>
                          </table>
                <button onclick="printTable('table-laporan')" class="btn-login" style="width:auto;margin:16px 0;">Cetak Laporan</button>
            <?php elseif (isset($_GET['laporan']) && $_GET['laporan']=='pengaduan'): ?>
                <h3 class="section-title">Laporan Pengaduan</h3>
                <?php
                // Ambil data pengaduan beserta foto dan komentar
                $laporan = $conn->query("SELECT pengaduan.*, user.nama as pelapor FROM pengaduan LEFT JOIN user ON pengaduan.user_id=user.id ORDER BY tanggal DESC");
                ?>
                <div class="table-responsive">
                    <table id="table-laporan" class="table table-bordered table-striped align-middle bg-white">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Pelapor</th>
                                <th>Isi Pengaduan</th>
                                <th>Bukti Foto</th>
                                <th>Komentar</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=1; while($row = $laporan->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['pelapor']) ?></td>
                                <td><?= htmlspecialchars($row['isi']) ?></td>
                                <td>
                                    <?php if (!empty($row['foto'])): ?>
                                        <a href="uploads/<?= htmlspecialchars($row['foto']) ?>" target="_blank">
                                            <img src="uploads/<?= htmlspecialchars($row['foto']) ?>" alt="foto" style="max-width:70px;max-height:70px;border-radius:6px;">
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= !empty($row['komentar']) ? nl2br(htmlspecialchars($row['komentar'])) : '<span class="text-muted">-</span>' ?>
                                </td>
                                <td><?= htmlspecialchars($row['tanggal']) ?></td>
                                <td><?= htmlspecialchars($row['status']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <button onclick="printTable('table-laporan')" class="btn btn-primary mt-2">Cetak Laporan</button>
            <?php elseif (isset($_GET['laporan']) && $_GET['laporan']=='komunikasi'): ?>
                <h3 class="section-title">Laporan Portal Komunikasi</h3>
                <?php
                $laporan = $conn->query("SELECT p.*, u.nama as penerima, peng.nama as pengirim 
                    FROM pesan p 
                    LEFT JOIN user u ON p.penerima_id = u.id 
                    LEFT JOIN user peng ON p.pengirim_id = peng.id
                    ORDER BY p.tanggal DESC");
                ?>
                <div class="table-responsive">
                    <table id="table-laporan" class="table table-bordered table-striped align-middle bg-white">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Pengirim</th>
                                <th>Penerima</th>
                                <th>Subjek</th>
                                <th>Isi Pesan</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=1; while($row = $laporan->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['pengirim']) ?></td>
                                <td><?= htmlspecialchars($row['penerima']) ?></td>
                                <td><?= htmlspecialchars($row['subjek']) ?></td>
                                <td><?= nl2br(htmlspecialchars($row['isi'])) ?></td>
                                <td><?= htmlspecialchars($row['tanggal']) ?></td>
                                <td><?= htmlspecialchars($row['status']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <button onclick="printTable('table-laporan')" class="btn btn-primary mt-2">Cetak Laporan</button>
            <?php elseif (isset($_GET['laporan']) && $_GET['laporan']=='distribusi'): ?>
                <h3 class="section-title">Laporan Distribusi Makanan</h3>
                <?php
                $laporan = $conn->query("
                    SELECT d.*, m.lauk_menu, m.jumlah, u.nama as sekolah
                    FROM distribusi_makanan d
                    JOIN makanan_kirim m ON d.makanan_id = m.id
                    JOIN user u ON m.sekolah_id = u.id
                    ORDER BY d.jadwal_kirim DESC
                ");
                ?>
                <div class="table-responsive">
                    <table id="table-laporan" class="table table-bordered table-striped align-middle bg-white">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Sekolah</th>
                                <th>Menu</th>
                                <th>Jadwal Kirim</th>
                                <th>Status Distribusi</th>
                                <th>Jumlah</th>
                                <th>Konfirmasi Penerima</th>
                                <th>Waktu Konfirmasi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=1; while($row = $laporan->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['sekolah']) ?></td>
                                <td><?= htmlspecialchars($row['lauk_menu']) ?></td>
                                <td><?= htmlspecialchars($row['jadwal_kirim']) ?></td>
                                <td><?= htmlspecialchars($row['status_distribusi']) ?></td>
                                <td><?= htmlspecialchars($row['jumlah']) ?></td>
                                <td>
                                    <?= $row['konfirmasi_penerima'] ? 'Sudah' : 'Belum' ?>
                                </td>
                                <td>
                                    <?= $row['waktu_konfirmasi'] ? htmlspecialchars($row['waktu_konfirmasi']) : '-' ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <button onclick="printTable('table-laporan')" class="btn btn-primary mt-2">Cetak Laporan</button>
            <?php endif; ?>
            <?php elseif ($menu=='komunikasi'): ?>
                <div class="banner-makan-gratis mb-4 p-3 rounded shadow-sm bg-white d-flex align-items-center" style="border-left: 6px solid var(--arya-green);">
                    <img src="https://cdn-icons-png.flaticon.com/512/2515/2515263.png" alt="Menu Bergizi" style="width:80px;height:80px;margin-right:32px;background:#fff;border-radius:50%;padding:10px;border:6px solid var(--arya-green);">
                    <div>
                        <div class="fw-bold" style="font-size:1.5rem;color:var(--arya-green);">Program Makan Siang Gratis</div>
                        <div style="color:var(--arya-gray);font-weight:500;">Dapatkan makan siang bergizi gratis untuk siswa sekolah!</div>
                    </div>
                </div>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="section-title mb-0">Portal Komunikasi</h3>
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formPesan">
            <i class="fas fa-plus"></i> Kirim Pesan ke Admin
        </button>
    </div>

    <!-- Filter by Status -->
    <form method="get" class="row g-2 mb-3 align-items-center">
        <input type="hidden" name="menu" value="komunikasi">
        <div class="col-md-3">
            <select name="filter_status_pesan" class="form-select" onchange="this.form.submit()">
                <option value="all" <?= (!isset($_GET['filter_status_pesan']) || $_GET['filter_status_pesan']=='all')?'selected':'' ?>>Semua Status</option>
                <option value="Belum Dibaca" <?= (isset($_GET['filter_status_pesan']) && $_GET['filter_status_pesan']=='Belum Dibaca')?'selected':'' ?>>Belum Dibaca</option>
                <option value="Sudah Dibaca" <?= (isset($_GET['filter_status_pesan']) && $_GET['filter_status_pesan']=='Sudah Dibaca')?'selected':'' ?>>Sudah Dibaca</option>
            </select>
        </div>
    </form>

    <!-- Tampilan Pesan -->
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title mb-3">Daftar Pesan</h5>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kepada</th>
                                    <th>Subjek</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                    <th>Isi Pesan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $page_komunikasi = isset($_GET['page_komunikasi']) ? max(1, intval($_GET['page_komunikasi'])) : 1;
                                $limit = 5;
                                $offset_komunikasi = ($page_komunikasi - 1) * $limit;
                                $filter_status_pesan = isset($_GET['filter_status_pesan']) ? $_GET['filter_status_pesan'] : 'all';
                                $status_pesan_sql = '';
                                if ($filter_status_pesan && $filter_status_pesan != 'all') {
                                    $status_pesan_sql = " AND p.status = '".$conn->real_escape_string($filter_status_pesan)."' ";
                                }
                                $total_pesan = $conn->query("SELECT COUNT(*) as total FROM pesan p WHERE p.pengirim_id = {$_SESSION['user_id']} $status_pesan_sql")->fetch_assoc()['total'];
                                $pesan_terkirim = $conn->query("
                                    SELECT p.*, u.nama as penerima 
                                    FROM pesan p 
                                    JOIN user u ON p.penerima_id = u.id 
                                    WHERE p.pengirim_id = {$_SESSION['user_id']} $status_pesan_sql
                                    ORDER BY p.tanggal DESC
                                    LIMIT $limit OFFSET $offset_komunikasi
                                ");
                                $no = 1 + $offset_komunikasi;
                                $pesan_terkirim->data_seek(0); while($p = $pesan_terkirim->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($p['penerima']) ?></td>
                                    <td><?= htmlspecialchars($p['subjek']) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($p['tanggal'])) ?></td>
                                    <td><span class="badge bg-<?= $p['status']=='Sudah Dibaca'?'success':'warning' ?>"> <?= $p['status'] ?> </span></td>
                                    <td>
                                        <button class="btn btn-sm btn-info" onclick="bacaPesan(<?= $p['id'] ?>, true)"><i class="fas fa-eye"></i> Lihat</button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php
                    $total_pages_komunikasi = ceil($total_pesan / $limit);
                    if ($total_pages_komunikasi > 1): ?>
                    <nav>
                      <ul class="pagination justify-content-center mt-3">
                        <li class="page-item<?= $page_komunikasi == 1 ? ' disabled' : '' ?>">
                          <a class="page-link" href="?menu=komunikasi&page_komunikasi=<?= $page_komunikasi-1 ?>&filter_status_pesan=<?= urlencode($filter_status_pesan) ?>">Previous</a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages_komunikasi; $i++): ?>
                          <li class="page-item<?= $page_komunikasi == $i ? ' active' : '' ?>">
                            <a class="page-link" href="?menu=komunikasi&page_komunikasi=<?= $i ?>&filter_status_pesan=<?= urlencode($filter_status_pesan) ?>"><?= $i ?></a>
                          </li>
                        <?php endfor; ?>
                        <li class="page-item<?= $page_komunikasi == $total_pages_komunikasi ? ' disabled' : '' ?>">
                          <a class="page-link" href="?menu=komunikasi&page_komunikasi=<?= $page_komunikasi+1 ?>&filter_status_pesan=<?= urlencode($filter_status_pesan) ?>">Next</a>
                        </li>
                      </ul>
                    </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Form Pesan -->
    <div class="modal fade" id="formPesan" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Kirim Pesan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" action="kirim_pesan.php">
                        <div class="mb-3">
                            <label class="form-label">Kepada Admin</label>
                            <select name="penerima_id" class="form-select" required>
                                <option value="">Pilih Admin</option>
                                <?php 
                                $admin_list = $conn->query("SELECT id, nama FROM user WHERE role='admin' ORDER BY nama");
                                while($a = $admin_list->fetch_assoc()): 
                                ?>
                                <option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['nama']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Subjek</label>
                            <input type="text" name="subjek" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Isi Pesan</label>
                            <textarea name="isi" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="text-end">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-success">Kirim</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Baca Pesan -->
    <div class="modal fade" id="modalBacaPesan" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Detail Pesan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <dl>
                        <dt><i class="fas fa-user"></i> Dari</dt>
                        <dd id="pesanPengirim"></dd>
                        <dt><i class="fas fa-envelope"></i> Subjek</dt>
                        <dd id="pesanSubjek"></dd>
                        <dt><i class="fas fa-calendar"></i> Tanggal</dt>
                        <dd id="pesanTanggal"></dd>
                        <dt><i class="fas fa-comment"></i> Pesan</dt>
                        <dd id="pesanIsi"></dd>
                        <div id="balasanSection">
                            <dt class="mt-4"><i class="fas fa-reply"></i> Balasan Admin</dt>
                            <dd id="pesanBalasan"><em>Belum ada balasan</em></dd>
                        </div>
                    </dl>
                </div>
            </div>
        </div>
    </div>

    <script>
    function bacaPesan(id, isSent = false) {
        fetch('baca_pesan.php?id=' + id)
            .then(response => response.json())
            .then(data => {
                if (data.status == 'success') {
                    let pesan = data.data;
                    let modal = new bootstrap.Modal(document.getElementById('modalBacaPesan'));
                    document.getElementById('pesanPengirim').textContent = pesan.pengirim;
                    document.getElementById('pesanSubjek').textContent = pesan.subjek;
                    document.getElementById('pesanIsi').textContent = pesan.isi;
                    document.getElementById('pesanTanggal').textContent = new Date(pesan.tanggal).toLocaleString();
                    
                    // Only show balasan for sent messages
                    let balasanSection = document.getElementById('balasanSection');
                    if (isSent) {
                        balasanSection.style.display = 'block';
                        let balasanElem = document.getElementById('pesanBalasan');
                        if (pesan.balasan) {
                            balasanElem.innerHTML = `
                                <div class="mt-2">
                                    <strong>${pesan.balasan.pengirim}</strong> - 
                                    <small>${new Date(pesan.balasan.tanggal).toLocaleString()}</small>
                                    <p class="mt-1">${pesan.balasan.isi}</p>
                                </div>
                            `;
                        } else {
                            balasanElem.innerHTML = '<em>Belum ada balasan</em>';
                        }
                    } else {
                        balasanSection.style.display = 'none';
                    }
                    
                    modal.show();
                }
            });
    }
    </script>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
function printTable(tableId) {
    var table = document.getElementById(tableId);
    var win = window.open('', '', 'width=1000,height=700');
    win.document.write('<html><head><title>Print</title>');
    win.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">');
    win.document.write('<style>body{font-family:Arial,sans-serif;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #888;padding:8px;} th{background:#eafaf1;color:#256b25;} tr:nth-child(even){background:#f7faf7;}</style>');
    win.document.write('</head><body>');
    win.document.write(table.outerHTML);
    win.document.write('</body></html>');
    win.document.close();
    win.focus();
    win.print();
    win.close();
}
</script>
<!-- Make sure Bootstrap JS is included before closing body tag -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
