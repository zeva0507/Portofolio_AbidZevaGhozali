<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'sekolah') {
    die("Unauthorized");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $status = $_POST['status'];
    $pesan = !empty($_POST['pesan']) ? $_POST['pesan'] : 'Konfirmasi ' . $status;
    
    // Pastikan distribusi ini milik sekolah yang login
    $stmt = $conn->prepare("
        SELECT m.sekolah_id 
        FROM distribusi_makanan d
        JOIN makanan_kirim m ON d.makanan_id = m.id
        WHERE d.id = ? AND m.sekolah_id = ?
    ");
    $stmt->bind_param("ii", $id, $_SESSION['user_id']);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE distribusi_makanan SET 
            status_distribusi = ?,
            konfirmasi_penerima = 1,
            waktu_konfirmasi = NOW(),
            catatan_sekolah = ?
            WHERE id = ?");
        $stmt->bind_param("ssi", $status, $pesan, $id);
        $stmt->execute();
        $stmt->close();
        echo "Success";
    } else {
        echo "Unauthorized";
    }
} else {
    echo "error: incomplete data";
}
