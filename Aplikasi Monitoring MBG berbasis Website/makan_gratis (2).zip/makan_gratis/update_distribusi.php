<?php
session_start();
include 'db.php';

if (isset($_POST['id']) && isset($_POST['status'])) {
    $id = intval($_POST['id']);
    $status = $_POST['status'];
    $catatan = isset($_POST['catatan']) ? $_POST['catatan'] : '';
    
    $query = "UPDATE distribusi_makanan SET status_distribusi = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $id);
    
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "error: missing parameters";
}
?>
