<?php
$host = "sql300.infinityfree.com";     // Ganti sesuai info dari panel
$user = "if0_39014863";        // Ganti dengan username dari panel
$pass = "zevaabid050725";         // Password database yang kamu buat
$db   = "if0_39014863_db_laundry"; // Ganti dengan nama database kamu

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
