<?php
header('Location: transaksi.php'); exit;
?>